import time

from selenium.webdriver.common.by import By

from utilities.BaseClass import BaseClass


class Test_Breadcrumbs(BaseClass):
    def test_FirstLevelBreadcrumbs(self):
        log = self.get_logger()
        HomePage_url = "https://prod1.novartis.com/"
        first_level = self.driver.find_element(By.XPATH,'//li[@class="breadcrumb-item"]/a[normalize-space()="Home"]')
        self.driver.execute_script("arguments[0].click();", first_level)
        time.sleep(2)
        current_URL = self.driver.current_url
        assert HomePage_url == current_URL,'First Level breadcrumbs is not working properly'
        log.info('First Level breadcrumb is navigated to the Home Page.')
        self.driver.back()

    def test_SecondLevelBreadcrumbs(self):
        log = self.get_logger()
        NewsPage_url = "https://prod1.novartis.com/news"
        second_level = self.driver.find_element(By.XPATH, '//li[@class="breadcrumb-item"]/a[normalize-space()="News"]')
        self.driver.execute_script("arguments[0].click();", second_level)
        time.sleep(2)
        current_URL = self.driver.current_url
        assert NewsPage_url == current_URL, 'Second Level breadcrumbs is not working properly'
        log.info('Second Level breadcrumb is navigated to the Home Page.')

