from selenium.webdriver.common.by import By

from utilities.BaseClass import BaseClass


class Test_ListView(BaseClass):
    def test_listView(self):
        log = self.get_logger()
        List_View_text = self.driver.find_element(By.XPATH,'//button[@class="toggle_text"] [normalize-space()="List View"]')
        self.driver.execute_script("arguments[0].click();",List_View_text)

        List_view = self.driver.find_element(By.XPATH, "//div[contains(@class,'list_view')]")
        assert List_view.is_displayed(), 'contents are not displayed in the List View'
        log.info('contents are displayed in the List View')

        Grid_View_text = self.driver.find_element(By.XPATH,'//button[@class="toggle_text"] [normalize-space()="Grid View"]')
        assert Grid_View_text.is_displayed(),'The text is not changed as Grid View'
        log.info('The text is changed as Grid View')

