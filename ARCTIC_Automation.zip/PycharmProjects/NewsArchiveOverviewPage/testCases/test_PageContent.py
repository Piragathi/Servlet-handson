import time

from selenium.webdriver.common.by import By

from utilities.BaseClass import BaseClass


class Test_PageContent(BaseClass):
    def test_PageContent(self):
        global result
        log = self.get_logger()
        Menus = self.driver.find_elements(By.CSS_SELECTOR,'ul[id="block-newsarchivenavigation"] li a')
        count = len(Menus)
        for i in range(count):
            j = str(i + 1)
            menu = self.driver.find_element(By.XPATH,
                                             "(//ul[@id='block-newsarchivenavigation']/li/a)[" + j + "]")
            data = menu.text
            self.driver.execute_script("arguments[0].click();",menu)
            time.sleep(2)
            page_content = self.driver.find_elements(By.CSS_SELECTOR, '[class="whole-item"]')
            for content in page_content:
                result = content.is_displayed()
            if result:
                log.info(data +' Menus had content Pages')
            else:
                log.info('No Result Found')