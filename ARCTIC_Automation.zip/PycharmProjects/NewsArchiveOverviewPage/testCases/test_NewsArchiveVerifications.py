from selenium.webdriver.common.by import By
from selenium.webdriver.support.color import Color

from utilities.BaseClass import BaseClass


class Test_NewsArchive(BaseClass):
    def test_verifications(self):
        log = self.get_logger()
        Banner_img = self.driver.find_element(By.CSS_SELECTOR,'img[class="img img-fluid"]')
        assert Banner_img.is_displayed(),'Banner image is not displayed properly'
        log.info('Banner image is displayed properly')

        Pattern = self.driver.find_element(By.CSS_SELECTOR,'div[class="background_stripe"]')
        assert Pattern.is_displayed(),'Pattern is not displayed properly'
        log.info('Pattern is displayed properly')

        Bread_crumbs = self.driver.find_element(By.CSS_SELECTOR,'ol[class="breadcrumb"]')
        assert Bread_crumbs.is_displayed(),'Breadcrumbs is not displayed properly'
        log.info('Breadcrumbs is displayed properly')

        Title = self.driver.find_element(By.CSS_SELECTOR,'[class="title"]')
        assert Title.is_displayed(),'Page Title is not displayed properly'
        log.info('Page Title is displayed properly')

        search_bar = self.driver.find_element(By.XPATH,'//input[contains(@id,"edit-search")]')
        assert search_bar.is_displayed(), 'Search Bar is not displayed properly'
        log.info('Search Bar is displayed properly')

        search_button = self.driver.find_element(By.XPATH,'//input[contains(@id,"edit-submit-news-archive")]')
        assert search_button.is_displayed(), 'Search Button is not displayed properly'
        log.info('search Button is displayed properly')

        toggle_over_view_txt= self.driver.find_element(By.CSS_SELECTOR,'[class="toggle_text"]')
        txt = toggle_over_view_txt.text
        assert txt == "List View" ,'Default List view text is not displayed'
        log.info("Default List view text is displayed")

        toggle_over_view = self.driver.find_element(By.XPATH,"//div[contains(@class,'grid_view')]")
        assert toggle_over_view.is_displayed(),'Default contents are not displayed in the Grid View'
        log.info('Default contents are displayed in the Grid View')

        From_date = self.driver.find_element(By.XPATH,"//label[normalize-space()='From Date']")
        assert From_date.is_displayed(),'Calendar-From date is not  displayed properly'
        log.info('Calendar-From date is displayed properly')

        To_date = self.driver.find_element(By.XPATH, "//label[normalize-space()='To Date']")
        assert To_date.is_displayed(), 'Calendar-To date is not  displayed properly'
        log.info('Calendar-To date is displayed properly')

        background_color = "#f1f1f1"
        All_menu = self.driver.find_element(By.XPATH,"//a[normalize-space()='All']")
        rgb = All_menu.value_of_css_property("background-color")
        hex = Color.from_string(rgb).hex
        assert hex == background_color,'All menu is not greyed out'
        log.info('All menu is greyed out')


        Pagination_no = self.driver.find_elements(By.CSS_SELECTOR,'[class="pagination js-pager__items"] li')
        for pg_no in Pagination_no:
            assert pg_no.is_displayed(),'Pagination Number is not render properly'
        log.info('Pagination Number is rendered properly')












