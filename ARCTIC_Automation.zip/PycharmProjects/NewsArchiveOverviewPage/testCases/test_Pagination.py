import time

from selenium.webdriver.common.by import By

from utilities.BaseClass import BaseClass


class Test_Pagination(BaseClass):
    def test_PaginationButton(self):
        log = self.get_logger()
        for i in range(1,9,1):
            num = str(i)
            Pagination_no = self.driver.find_element(By.XPATH,"(//ul[@class='pagination js-pager__items']/li/a)[" + num + "]")
            self.driver.execute_script("arguments[0].click();", Pagination_no)
            pg_no = Pagination_no.text
            log.info('Pagination is working properly')





