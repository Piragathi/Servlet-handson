from datetime import date

from selenium.webdriver.common.by import By

from utilities.BaseClass import BaseClass


class Test_MediaRelease(BaseClass):
    def test_MediaRelease(self):
        log = self.get_logger()
        Media_release_button = self.driver.find_element(By.XPATH,"//a[normalize-space()='Media Releases']")
        self.driver.execute_script("arguments[0].click();",Media_release_button)
        Media_release_date = self.driver.find_element(By.XPATH,'(//span[contains(@class,"field-date views-")]/span)[1]')
        Media_date = Media_release_date.text
        assert "Dec 23, 2021" == Media_date,'The Media Release content Pages are not appeared on latest date order'
        log.info('The Media Release content Pages appeared on latest date order')