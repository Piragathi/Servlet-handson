import time

from selenium.webdriver.common.by import By

from utilities.BaseClass import BaseClass


class Test_ArrowButtons(BaseClass):

    def test_forward_arrow(self):
        log = self.get_logger()
        page = self.driver.find_element(By.XPATH, '//li[@class="page-item "] [normalize-space()="4"]/a')
        self.driver.execute_script("arguments[0].click();", page)
        initailpagno = int(page.text)
        time.sleep(2)
        forwardbutton = self.driver.find_element(By.CSS_SELECTOR, '[title="Go to next page"]')
        self.driver.execute_script("arguments[0].click();", forwardbutton)
        time.sleep(2)
        currentpageno = self.driver.find_element(By.CSS_SELECTOR, '[class="page-item active"] span')
        num  =currentpageno.text
        current_no = int(num)
        assert initailpagno < current_no, "forward button is not working"
        log.info('Forward button is working,It navigated to the respective forward page')



    def test_backward_arrow(self):
        log = self.get_logger()
        initialpage = self.driver.find_element(By.CSS_SELECTOR, '[class="page-item active"] span').text
        initailpagno = int(initialpage)
        time.sleep(2)
        backwardbutton = self.driver.find_element(By.CSS_SELECTOR, '[title="Go to previous page"]')
        self.driver.execute_script("arguments[0].click();", backwardbutton)
        time.sleep(2)
        currentpageno = self.driver.find_element(By.CSS_SELECTOR, '[class="page-item active"] span')
        num = currentpageno.text
        current_no = int(num)
        assert initailpagno > current_no, "backward button is not working"
        log.info('Backward button is working,It navigated to the respective backward page')