from selenium.webdriver.common.by import By

from utilities.BaseClass import BaseClass


class Test_LanguageTab(BaseClass):
    def test_languageTab(self):
        log = self.get_logger()
        Key_Release_button = self.driver.find_element(By.XPATH,"//a[normalize-space()='Key Releases']")
        self.driver.execute_script("arguments[0].click();",Key_Release_button)
        Language_tab = self.driver.find_element(By.CSS_SELECTOR,'label[title="Language"]')
        assert Language_tab.is_displayed(),'Language Tab is not rendered'
        log.info('Language Tab is rendered properly')

        self.driver.execute_script("arguments[0].click();",Language_tab)
        Language_list = self.driver.find_elements(By.XPATH,"//ul[contains(@class,'language-list')]/li")
        for list in Language_list:
            assert list.is_displayed(),'Language list is not displayed properly'
        log.info('Language list is displayed properly')

