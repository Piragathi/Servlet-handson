import time

from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait

from utilites.BaseClass import BaseClass


class TestPopup(BaseClass):
    def test_popup_window(self):

        log = self.get_logger()

        ext_links = self.driver.find_elements(By.CSS_SELECTOR, "ul[class*='social-media-links'] a")
        for ex_link in ext_links:

            self.driver.execute_script("arguments[0].click();",ex_link )
            time.sleep(3)
            assert self.driver.find_element(
                By.CSS_SELECTOR, "div[class*='external-link-popup-id-default']").is_displayed(),"Pop up window is not displayed for external link"
            message = ex_link.get_attribute('title')
            msg = message + " popup window is displayed"
            log.info(msg)

    def test_popup_disclaimer(self):
        log = self.get_logger()

        assert self.driver.find_element(By.CSS_SELECTOR, "div[class*='ui-dialog-titlebar'] img[src*='logo']").is_displayed(), "logo is not visible in the popup window"
        log.info("Logo is visible in pop up window")

        Dis_msg = self.driver.find_element(By.XPATH,"//span[@id='ui-id-5']").text
        assert "leaving the Novartis.com" in Dis_msg
        log.info("Disclaimer message is verified")
        cancel=self.driver.find_element(By.XPATH, "//div[@class='ui-dialog-buttonset']/button[text()='Cancel']")
        self.driver.execute_script("arguments[0].click();", cancel)


    def test_popup_cancel(self):
        log = self.get_logger()

        ext_links = self.driver.find_elements(By.CSS_SELECTOR, "ul[class*='social-media-links'] a")
        for ex_link in ext_links:
            self.driver.execute_script("arguments[0].click();", ex_link)
            button=self.driver.find_element(By.XPATH, "//div[@class='ui-dialog-buttonset']/button[text()='Cancel']")
            message = ex_link.get_attribute('title')
            self.driver.execute_script("arguments[0].click();", button)
            try:
                self.driver.find_element(By.XPATH, "//div[@class='ui-dialog-buttonset']/button[text()='Cancel']")
            except NoSuchElementException:
                self.assertRaises(NoSuchElementException)
            msg = message + ", Cancel button is working "
            log.info(msg)

    def test_popup_continue(self):
        log = self.get_logger()
        URL = "https://qa1.novartis.com/"

        ext_links = self.driver.find_elements(By.CSS_SELECTOR, "ul[class*='social-media-links'] a")
        for ex_link in ext_links:
            self.driver.execute_script("arguments[0].click();", ex_link)
            message = ex_link.get_attribute('title')
            con_button = self.driver.find_element(By.XPATH,"//button[text()='Continue']")
            self.driver.execute_script("arguments[0].click();",con_button )
            time.sleep(2)
            new_window =self.driver.window_handles[1]
            self.driver.switch_to.window(new_window)

            URL1 = self.driver.current_url
            log.info(URL1)
            self.driver.close()

            assert not URL == URL1, "continue button is not working"
            msg = message + ", Continue button is working "
            log.info(msg)
            self.driver.switch_to.window(self.driver.window_handles[0])



















