import time

import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait
from selenium.common.exceptions import TimeoutException
from utilites.BaseClass import BaseClass


class TestMegamenu(BaseClass):
    @pytest.mark.skip
    def test_menu(self):
        log = self.get_logger()
        mega_button= self.driver.find_element(By.CSS_SELECTOR, '[href="#menu"]')
        self.driver.execute_script("arguments[0].click();", mega_button)
        Mega_menus =self.driver.find_elements(By.CSS_SELECTOR, "ul[class*='we-mega-menu'] a")

        for menu in Mega_menus:
            try:
                self.driver.set_page_load_timeout(1)
                WebDriverWait(self.driver, 2).until(expected_conditions.element_to_be_clickable(menu))
            except TimeoutException as ex:
                log.info("Exception has been thrown. " + str(ex))


        log.info("All Mega menus and sub menus  are clickable")


    def test_alignment(self):
        log = self.get_logger()
        mega_button = self.driver.find_element(By.CSS_SELECTOR, '[href="#menu"]')
        self.driver.execute_script("arguments[0].click();", mega_button)
        alignment = self.driver.find_elements(By.CSS_SELECTOR, '[class*="we-mega-menu-ul"] li[data-level="0"]')

        for alg in (alignment[0:7]):
            store = alg.value_of_css_property("text-align")
            log.info(store)
            assert store == "left"

        log.info("All menus are present at left")









