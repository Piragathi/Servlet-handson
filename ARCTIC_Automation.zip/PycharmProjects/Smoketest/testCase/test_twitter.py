import time

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait

from utilites.BaseClass import BaseClass


class TestTwitter(BaseClass):
    def test_twitterCarousel(self):
        log = self.get_logger()
        carousel_links = self.driver.find_elements(By.XPATH, '//ol[@class="carousel-indicators"]/li[@data-target="#card3-paragraph--34836"]')
        carousel_size = len(self.driver.find_elements(By.CSS_SELECTOR, 'ol[class="carousel-indicators"] li'))

        if carousel_size>0:
            for link in carousel_links:
                self.driver.execute_script("arguments[0].click();", link)

                assert link.find_element(By.XPATH,'parent::ol/preceding-sibling::div//div[@class="container"]//p//a').is_displayed() ,'twitter link is not displayed'
                twitter_link=link.find_element(By.XPATH, 'parent::ol/preceding-sibling::div//div[@class="container"]//p//a')
                wait = WebDriverWait(self.driver, 10)
                assert wait.until(expected_conditions.element_to_be_clickable(twitter_link)),'twitter link cannot able to click'
            log.info('Twitter carousel is verified')
        else:
            log.info("carousel is not present")






