import time

from selenium.webdriver.common.by import By

from utilites.BaseClass import BaseClass


class TestFooterSearch(BaseClass):
    def test_footer_search(self):
        log = self.get_logger()
        navigate_url ="https://qa1.novartis.com/search?keyword=novartis&type=All&created=&created_1=&tid=&sort_by=search_api_relevance"


        self.driver.find_element(By.ID, "edit-keys").send_keys("novartis")
        search =self.driver.find_element(By.ID, "edit-submit")
        self.driver.execute_script("arguments[0].click();", search)
        time.sleep(2)
        URL= self.driver.current_url
        assert "search?keyword" in URL
        log.info(navigate_url)
        log.info("Page route to Global Search")