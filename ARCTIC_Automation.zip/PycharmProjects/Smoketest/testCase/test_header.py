import time

import pytest
from selenium.webdriver.common.by import By
import requests
from requests.exceptions import MissingSchema, InvalidSchema, InvalidURL
import urllib3
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait

from utilites.BaseClass import BaseClass


class Test_Header(BaseClass):

    def test_verifyLogo(self):
        log = self.get_logger()
        assert self.driver.find_element(By.CSS_SELECTOR,"img[src*='logo']").is_displayed(), "logo is not visible"
        log.info("Logo is visible")


    def test_images(self):
        log = self.get_logger()
        iBrokenImageCount = 0
        img_list= self.driver.find_elements(By.CSS_SELECTOR, "img[class*='img']")
        for img in img_list:
            try:
                response = requests.get(img.get_attribute('src'), stream=True)
                if (response.status_code != 200):
                    log.info(img.get_attribute('outerHTML') + " is broken.")
                    iBrokenImageCount = (iBrokenImageCount + 1)
            except requests.exceptions.MissingSchema:
                log.info("Encountered MissingSchema Exception")
            except requests.exceptions.InvalidSchema:
                log.info("Encountered InvalidSchema Exception")

            except:
                log.info("Encountered Some other Exception")

        log.info("Images are loaded properly")
        log.info(str(iBrokenImageCount) + " broken image")


    def test_video(self):
        log = self.get_logger()
        video_clip = self.driver.find_elements(By.CSS_SELECTOR, 'button[title="Play clip"]')
        for video in video_clip:
            self.driver.execute_script("arguments[0].click();", video)
        log.info("video loaded properly")


    def test_pattern(self):
        log = self.get_logger()
        assert self.driver.find_element(By.CSS_SELECTOR, 'div[class="background_stripe"]').is_displayed(),'Pattern is not displayed'
        log.info("Pattern is displayed")

    def test_button(self):
        log = self.get_logger()
        buttons = self.driver.find_elements(By.CSS_SELECTOR, "a[class*='link_button']")
        for button in buttons:
            wait = WebDriverWait(self.driver, 10)
            wait.until(expected_conditions.element_to_be_clickable(button))
        log.info("All buttons are clickable")

    def test_header_carousel(self):
        log = self.get_logger()
        header_carousel_links = self.driver.find_elements(By.XPATH,
                                                   '//ol[@class="carousel-indicators"]/li[@data-target="#paragraph--37036"]')
        carousel_size = len(header_carousel_links)

        if carousel_size > 0:
            for header_link in header_carousel_links:
                self.driver.execute_script("arguments[0].click();", header_link)

                assert header_link.find_element(By.XPATH,
                                         'parent::ol/preceding-sibling::div//img').is_displayed(), 'header carousel image is not displayed'

            log.info('Header carousel is verified')
        else:
            log.info("Header carousel is not present")


    def test_herotext(self):
        log = self.get_logger()
        header_carousel_links = self.driver.find_elements(By.XPATH,
                                                          '//ol[@class="carousel-indicators"]/li[@data-target="#paragraph--37036"]')
        time.sleep(2)
        carousel_size = len(header_carousel_links)

        if carousel_size > 0:
            for header_link in header_carousel_links:
                self.driver.execute_script("arguments[0].click();",header_link)
                if header_link.find_element(By.XPATH,
                                                'parent::ol/preceding-sibling::div//div[@class="carousel_inner--wrapper  "]').is_displayed():
                    log.info("Hero text is present")

                else:
                    log.info("Hero text is not present")


    def test_hyperlinks(self):
        log = self.get_logger()
        hyperlinks = self.driver.find_elements(By.CSS_SELECTOR, 'div[class="card_content"]')
        for hyper_link in hyperlinks:
            wait = WebDriverWait(self.driver,3)
            assert wait.until(expected_conditions.element_to_be_clickable(hyper_link)),'Hyperlink is not clickable'
        log.info("All hyperlinks are clickable")











