from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait

from utilites.BaseClass import BaseClass


class Testfooter(BaseClass):

    def test_footer_heading(self):
        log = self.get_logger()
        assert self.driver.find_element(By.ID, 'block-novartisglobal').is_displayed(),"Footer heading is not displayed"
        log.info("Footer heading is displayed")

    def test_footer_link(self):
         log = self.get_logger()
         menus= self.driver.find_elements(By.CSS_SELECTOR, "div[class='footer-widgets'] a")
         for menu in menus:
             WebDriverWait(self.driver, 3).until(expected_conditions.element_to_be_clickable(menu))
         log.info("All links are clickable")

    def test_footer_menu(self):
         log = self.get_logger()
         links= self.driver.find_elements(By.CSS_SELECTOR, "ul[id='block-footerbottom'] a")
         for link in links:
             WebDriverWait(self.driver, 3).until(expected_conditions.element_to_be_clickable(link))
         log.info("All menus are clickable")



