from selenium.webdriver.common.by import By

from utilites.BaseClass import BaseClass


class Test_Search(BaseClass):
    def test_search(self):
        log = self.get_logger()

        log.info('Home Page is displayed properly')

        search_Placeholder = self.driver.find_element(By.XPATH,'(//input[@placeholder="Search"])[1]')
        assert search_Placeholder.is_displayed(),'Search Placeholder is not displayed properly'
        log.info('Search Placeholder is displayed properly')

        search_bar = self.driver.find_element(By.ID,'edit-keyword')
        assert search_bar.is_displayed(),'Search Bar is not displayed properly'
        log.info('Search Bar is  displayed properly')

        Global_search = self.driver.find_element(By.XPATH,"//span[normalize-space()='Global Search']")
        assert Global_search.is_displayed(),'Global Search is not displayed properly'
        log.info('Global Search is  displayed properly')

        Search_icon = self.driver.find_element(By.ID,'edit-submit-global-search')
        assert Search_icon.is_displayed,'Search Icon is not displayed properly'
        log.info('Serch icon is displayed properly')


