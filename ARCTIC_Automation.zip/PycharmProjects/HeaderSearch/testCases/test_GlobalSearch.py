import time

from selenium.webdriver.common.by import By

from utilites.BaseClass import BaseClass


class Test_GlobalSearch(BaseClass):
    def test_GlobalSearch(self):
        log = self.get_logger()
        navigate_url ="https://prod1.novartis.com/search?keyword=novartis&type=All&created=&created_1=&tid=&sort_by=search_api_relevance"


        search_bar = self.driver.find_element(By.ID,'edit-keyword')
        search_bar.send_keys('novartis')
        Search_icon = self.driver.find_element(By.ID,'edit-submit-global-search')
        self.driver.execute_script("arguments[0].click();", Search_icon)
        time.sleep(2)
        URL= self.driver.current_url
        assert "search?keyword" in URL
        log.info(navigate_url)
        log.info("Page to navigated to Global Search.")

    def test_globalSearch_icon(self):
        log = self.get_logger()
        expected_filterd_list =['Global', 'Digital','ESG', 'Media Center', 'Careers' ]
        original_filtered_list=[]


        globalsearch_icon = self.driver.find_element(By.XPATH,"//div[@id='ms-list-1']//button[@type='button']")
        globalsearch_icon.click()

        globalSearch_filters = self.driver.find_elements(By.XPATH,"//div[@id='ms-list-1']//button[@type='button']//following-sibling::div/ul/li/label/input")
        for i in globalSearch_filters:
            assert i.is_displayed()
            value = i.get_attribute('title')
            original_filtered_list.append(value)
        log.info(original_filtered_list)
        assert expected_filterd_list == original_filtered_list ,'Filter Text are not displayed properly in Order'
        log.info('Filter Text are displayed properly in Order')

        clearAll_button = self.driver.find_element(By.CSS_SELECTOR,'[class="section-uncheck-all"] input')
        clearAll_button.is_displayed()
        log.info('Cancel button is displayed properly')

    def test_globalSearchFilter(self):
        global list
        global After_selection
        log = self.get_logger()
        list = ['Global', 'Careers']
        value = len(list)
        value1 = str(value)

        globalSearch_filters = self.driver.find_elements(By.XPATH,
                                                         "//div[@id='ms-list-1']//button[@type='button']//following-sibling::div/ul/li/label/input")

        for i in globalSearch_filters:
            value = i.get_attribute('title')
            for j in list:
                if value == j:
                    self.driver.execute_script("arguments[0].click();", i)
                    break
        globalsearch_icon = self.driver.find_element(By.XPATH,"//div[@id='ms-list-1']//button[@type='button']/span")
        After_selection = globalsearch_icon.text
        assert value1 in After_selection, 'The selected count is not added in the Global search'
        log.info('The selected count is  added in the Global search')

    def test_clearAll(self):
        log = self.get_logger()
        clearAll_button = self.driver.find_element(By.CSS_SELECTOR, '[class="section-uncheck-all"] input')
        clearAll_button.click()
        globalsearch_icon = self.driver.find_element(By.XPATH, "//div[@id='ms-list-1']//button[@type='button']/span")
        After_clearAll = globalsearch_icon.text
        assert not After_selection == After_clearAll,' clear All functionality is not working'
        log.info('none of filter is highlighted and count is  not display')

    def test_Search(self):
        log = self.get_logger()
        currentUrl = self.driver.current_url
        search = self.driver.find_element(By.CSS_SELECTOR,'[class="nav-item search"]')
        search.click()
        after_clickURL = self.driver.current_url
        log.info(currentUrl)
        log.info(after_clickURL)
        assert not currentUrl == after_clickURL,'Page that was previously being viewed not displays'
        log.info('Page that was previously being viewed displayed')





