import pytest
import time

from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager

@pytest.fixture(scope='class')
def setup(request):
    s = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=s)
    request.cls.driver = driver
    driver.get('https://prod1.novartis.com/')
    driver.maximize_window()
    time.sleep(2)
    button = driver.find_element(By.XPATH, "//button[@id='onetrust-accept-btn-handler']")
    driver.execute_script("arguments[0].click();", button)
    driver.find_element(By.XPATH,'//li[@class="nav-item menu"]/button[contains(@class,"nav-link")]').click()
    action = ActionChains(driver)
    action.move_to_element(
        driver.find_element(By.XPATH, "(//li[contains(@class,'dropdown-menu')]/a[@href='/news'])")).perform()
    driver.find_element(By.XPATH, '//a[@href="/news/media-library"]').click()
    time.sleep(3)