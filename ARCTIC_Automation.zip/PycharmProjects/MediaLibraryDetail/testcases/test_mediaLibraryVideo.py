import time

from selenium.webdriver.common.by import By

from utilites.BaseClass import BaseClass


class Test_MediaLibraryVideo(BaseClass):
    def test_Video(self):
        log = self.get_logger()
        self.driver.find_element(By.CSS_SELECTOR, '[href="/news/media-library/video"]').click()
        videos = self.driver.find_elements(By.CSS_SELECTOR, 'div[class="document-type-Video"]')
        Total_video = len(videos)
        for i in range(Total_video):
            j = str(i + 1)
            doc = self.driver.find_element(By.XPATH, "(//div[@Class='document-asset'])[" + j + "]")
            self.driver.execute_script("arguments[0].click();", doc)
            log.info('Video Page loaded properly')
            time.sleep(2)
            labels = self.driver.find_elements(By.CSS_SELECTOR, '[class="field__label"]')
            for label in labels:
                assert label.is_displayed(), 'Labels not displayed properly'
                log.info('Description and Usage Rights & Restrictions displayed properly')
            self.driver.find_element(By.CSS_SELECTOR,'[class="prev_but"] a').click()