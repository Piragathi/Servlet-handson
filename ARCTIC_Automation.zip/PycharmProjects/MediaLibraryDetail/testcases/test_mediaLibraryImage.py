import time

from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait

from utilites.BaseClass import BaseClass


class Test_MediaLibraryImage(BaseClass):


    def test_Image(self):
        log = self.get_logger()
        self.driver.find_element(By.CSS_SELECTOR, '[href="/news/media-library/image"]').click()
        images = self.driver.find_elements(By.CSS_SELECTOR, 'div[class="document-type-Image"]')
        Total_image = len(images)
        for i in range(Total_image):
            j = str(i + 1)
            img = self.driver.find_element(By.XPATH, "(//div[@Class='document-asset'])[" + j + "]")
            self.driver.execute_script("arguments[0].click();", img)
            try:
                value =self.driver.find_element(By.XPATH,"//div[@class='col-sm-6 media_img']/img")
                val= value.get_attribute('src')
                assert not 'lock-image' in val
                log.info('Non-protected Image')
                assert value.is_displayed(),'Image is not display'
                log.info('Image displayed properly')
                download_button= self.driver.find_element(By.CSS_SELECTOR,'div[class*="paragraph--type--product-documents"]')
                assert download_button.is_displayed(),'download option is not display'
                log.info('Download button is present')
                wait = WebDriverWait(self.driver, 3)
                assert wait.until(expected_conditions.element_to_be_clickable(download_button)), 'Download Button is not clickable'
                log.info('Download button is clickable')
            except:

                value1 =self.driver.find_element(By.XPATH,'(//div[@class="lockimagewrap opt"]//a[@class=" use-ajax"]/img)[1]')
                val1 = value1.get_attribute('src')
                assert 'lock-image' in val1
                log.info('Protected image')

            self.driver.back()

    def test_ProtectedImage(self):
        self.driver.find_element(By.CSS_SELECTOR, '[href="/news/media-library/image"]').click()
        log = self.get_logger()
        lock_image = self.driver.find_element(By.XPATH, '//i[@class="fa fa-lock"]//parent::div')
        self.driver.execute_script("arguments[0].click();", lock_image)
        value1 = self.driver.find_element(By.XPATH,
                                          '(//div[@class="lockimagewrap opt"]//a[@class=" use-ajax"]/img)[1]')
        self.driver.execute_script("arguments[0].click();", value1)

        time.sleep(2)
        yes = self.driver.find_element(By.XPATH,"//a[text()='Yes']")
        wait = WebDriverWait(self.driver, 3)
        assert wait.until(expected_conditions.element_to_be_clickable(yes)), 'Yes Button is not clickable'
        log.info('Pop up displayed properly')
        log.info('Yes button is working properly')
        No = self.driver.find_element(By.XPATH,"//a[text()='No']")
        self.driver.execute_script("arguments[0].click();", No)
        time.sleep(2)
        try:
            self.driver.find_element(By.XPATH,"//a[text()='No']")
        except:
            log.info('Nobutton is working properly')

