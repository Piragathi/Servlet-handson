import time

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait

from utilites.BaseClass import BaseClass


class Test_MediaLibraryDocument(BaseClass):
    def test_Document(self):
        log = self.get_logger()
        self.driver.find_element(By.CSS_SELECTOR, '[href="/news/media-library/document"]').click()
        documents = self.driver.find_elements(By.CSS_SELECTOR, 'div[class="document-type-PDF"]')
        Total_document = len(documents)
        for i in range(Total_document):
            j = str(i + 1)
            doc = self.driver.find_element(By.XPATH, "(//div[@Class='document-asset'])[" + j + "]")
            self.driver.execute_script("arguments[0].click();", doc)
            try:
                value = self.driver.find_element(By.XPATH, "//div[@class='col-sm-6 media_img']/img")
                val = value.get_attribute('src')
                assert not 'lock-image' in val
                log.info('Non-protected document')
                labels = self.driver.find_elements(By.CSS_SELECTOR, '[class="field__label"]')
                for label in labels:
                    assert label.is_displayed(), 'Labels not displayed properly'
                    log.info('Description and Usage Rights & Restrictions displayed properly')
                download_button = self.driver.find_element(By.CSS_SELECTOR,
                                                           'div[class*="paragraph--type--product-documents"]')
                assert download_button.is_displayed(), 'download option is not display'
                log.info('Download button is present')
                wait = WebDriverWait(self.driver, 3)
                assert wait.until(
                    expected_conditions.element_to_be_clickable(download_button)), 'Download Button is not clickable'
                log.info('Download button is clickable')


            except:

                value1 = self.driver.find_element(By.XPATH,
                                                  "//div[@class='col-sm-5 media_img']//a[@class='apply_btn use-ajax']/img")
                val1 = value1.get_attribute('src')
                assert 'lock-image' in val1
                log.info('Protected document')
            self.driver.back()

    def test_ProtectedDocument(self):
        self.driver.find_element(By.CSS_SELECTOR, '[href="/news/media-library/infographic"]').click()
        log = self.get_logger()
        protected_documents = self.driver.find_elements(By.CSS_SELECTOR, '[class="fa fa-lock"]')
        total_count =len(protected_documents)
        for i in range(total_count):
            j = str(i + 1)
            doc = self.driver.find_element(By.XPATH, "(//i[@class='fa fa-lock']//parent::div)[" + j + "]")
            self.driver.execute_script("arguments[0].click();", doc)
            value1 = self.driver.find_element(By.XPATH,
                                          '(//div[@class="lockimagewrap opt"]//a[@class=" use-ajax"]/img)[1]')
            self.driver.execute_script("arguments[0].click();", value1)

            time.sleep(2)
            yes = self.driver.find_element(By.XPATH,"//a[text()='Yes']")
            wait = WebDriverWait(self.driver, 3)
            assert wait.until(expected_conditions.element_to_be_clickable(yes)), 'Yes Button is not clickable'
            log.info('Pop up displayed properly')
            log.info('Yes button is working properly')
            No = self.driver.find_element(By.XPATH,"//a[text()='No']")
            self.driver.execute_script("arguments[0].click();", No)
            time.sleep(2)
            try:
                self.driver.find_element(By.XPATH,"//a[text()='No']")
            except:
                log.info('No button is working properly')
            self.driver.back()
