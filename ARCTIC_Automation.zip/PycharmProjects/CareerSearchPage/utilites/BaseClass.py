import inspect

import pytest
import logging

@pytest.mark.usefixtures("setup")
class BaseClass:

    def get_logger(self):
        loggerName = inspect.stack()[1][3]
        logger = logging.getLogger(loggerName)

        fileHandler=logging.FileHandler("logfile.log")
        formatter = logging.Formatter("%(asctime)s : %(name)s  : %(levelname)s  : %(message)s ")
        fileHandler.setFormatter(formatter)
        logger.addHandler(fileHandler)


        logger.setLevel(logging.INFO)


        return logger