from selenium.webdriver.common.by import By

from utilites.BaseClass import BaseClass


class Test_Breadcrumbs(BaseClass):
    def test_breadcrumbs(self):
        log = self.get_logger()
        breadcrumbs = self.driver.find_elements(By.XPATH, "//li[@class='breadcrumb-item']/a")
        for bc in breadcrumbs:
            assert bc.is_displayed(),'Breadcrumbs is not display properly'
        log.info('Breadcrumbs is displayed properly')