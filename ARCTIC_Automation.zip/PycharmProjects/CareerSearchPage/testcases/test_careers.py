from selenium.webdriver.common.by import By

from utilites.BaseClass import BaseClass


class Test_Careers(BaseClass):
    def test_CareersImage_HeroText(self):
        self.driver.find_element(By.CSS_SELECTOR, 'li[class="breadcrumb-item"] a[href="/careers"]').click()
        log = self.get_logger()

        header_image =self.driver.find_element(By.XPATH,'(//div[contains(@class,"field--name-field-image")]//img[@class="img img-fluid"])[1]')
        assert header_image.is_displayed(),'Image is not displayed properly '
        log.info('Image is displayed properly')
        hero_text =self.driver.find_element(By.XPATH,'(//div[contains(@class,"field--name-field-image")]//img[@class="img img-fluid"])[1]//parent::div/parent::div/following-sibling::div/div/div')
        assert hero_text.is_displayed(),'HeroText is not displayed properly'
        log.info('Hero Text is displayed properly')

    def test_Featured_Stripes(self):
        log = self.get_logger()
        search_textbox = self.driver.find_element(By.CSS_SELECTOR, 'input[placeholder="Search Job"]')
        assert search_textbox.is_displayed(), 'Search textbox is not displayed'
        log.info('Search TextBox is displayed properly')

        Function = self.driver.find_element(By.ID, 'ms-list-3')
        assert Function.is_displayed(), 'Function Dropdown is not displayed properly'
        log.info('Function Dropdown is displayed properly')

        Location = self.driver.find_element(By.ID, 'ms-list-2')
        assert Location.is_displayed(), 'Location Dropdown is not displayed properly'
        log.info('Location Dropdown is displayed properly')

        Search_button = self.driver.find_element(By.CSS_SELECTOR, '[id="edit-submit-career-search"]')
        assert Search_button.is_displayed(), 'Search button is not displayed properly'
        log.info('Search button is displayed properly')

        Title = self.driver.find_element(By.CSS_SELECTOR,'[class="title"]')
        assert Title.is_displayed(),'Title is not displayed properly'
        log.info('Title is displayed properly')


