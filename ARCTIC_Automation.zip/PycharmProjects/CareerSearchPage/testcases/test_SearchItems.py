from selenium.webdriver.common.by import By

from utilites.BaseClass import BaseClass


class Test_SearchItems(BaseClass):

    def test_Searchitems(self):
        log = self.get_logger()
        search_textbox= self.driver.find_element(By.CSS_SELECTOR, 'input[placeholder="Search Job"]')
        assert search_textbox.is_displayed(),'Search textbox is not displayed'
        log.info('Search TextBox is displayed properly')

        Function = self.driver.find_element(By.ID,'ms-list-3')
        assert Function.is_displayed(),'Function Dropdown is not displayed properly'
        log.info('Function Dropdown is displayed properly')

        Location = self.driver.find_element(By.ID,'ms-list-2')
        assert Location.is_displayed(), 'Location Dropdown is not displayed properly'
        log.info('Location Dropdown is displayed properly')

        Search_button = self.driver.find_element(By.CSS_SELECTOR,'[id="edit-submit-career-search--2"]')
        assert Search_button.is_displayed(),'Search button is not displayed properly'
        log.info('Search button is displayed properly')


    def test_Location(self):
        global list
        log = self.get_logger()
        list =['Canada','China','Germany','India','USA']
        value = len(list)
        value1 =str(value)

        Location_button = self.driver.find_element(By.XPATH, "//button[@type='button']/span[text()='Location']")
        Location_button.click()
        countries = self.driver.find_elements(By.XPATH,
                                              "//button[@type='button']/span[text()='Location']//parent::button/following-sibling::div/ul/li/label/input")
        for i in countries:
            value = i.get_attribute('title')
            for j in list:
                if value == j:
                    self.driver.execute_script("arguments[0].click();", i)
                    break
        Location_button = self.driver.find_element(By.XPATH, "(//button[@type='button']/span)[3]")
        After_selection =Location_button.text
        assert value1 in After_selection,'Location filter is not working properly'
        log.info('Location filter count is working properly')

    def test_Function(self):
        global list1
        log = self.get_logger()
        list1 = ['Audit & Finance', 'Human Resources', 'Information Technology']
        value = len(list1)
        value1 = str(value)

        Function_button = self.driver.find_element(By.ID, 'ms-list-3')
        Function_button.click()
        categories= self.driver.find_elements(By.XPATH,
                                              "//button[@type='button']/span[text()='Function']//parent::button/following-sibling::div/ul/li/label/input")
        for i in categories:
            value = i.get_attribute('title')
            for j in list1:
                if value == j:
                    self.driver.execute_script("arguments[0].click();", i)
                    break
        Function_button = self.driver.find_element(By.XPATH, "(//button[@type='button']/span)[2]")
        After_selection = Function_button.text
        assert value1 in After_selection, 'Function filter is not working properly'
        log.info('Function filter count is working properly')


    def test_filters(self):


        log = self.get_logger()
        Search_button = self.driver.find_element(By.CSS_SELECTOR, '[id="edit-submit-career-search--2"]')
        self.driver.execute_script("arguments[0].click();", Search_button)

        applied_filters = self.driver.find_elements(By.XPATH,'//div[@class="query-attribute"]')
        for i in applied_filters:
            assert i.is_displayed(),'Not filter out the required items'
        log.info('Filtered out the reqired items')











