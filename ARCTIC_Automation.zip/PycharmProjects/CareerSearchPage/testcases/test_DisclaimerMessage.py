from selenium.webdriver.common.by import By

from utilites.BaseClass import BaseClass


class Test_DisclaimerMessage(BaseClass):
    def test_disclaimer_Message(self):
        log = self.get_logger()
        try:
            assert self.driver.find_element(By.XPATH,
                                            "//div[normalize-space()='Disclaimer']").is_displayed(), 'Disclaimer is not present in the page'
            Message= self.driver.find_elements(By.XPATH,"//div[normalize-space()='Disclaimer']//parent::div/following-sibling::div/p")
            assert Message.is_displayed(),'Disclaimer Message is not displayed properly'
            log.info('Disclaimer Message is displayed properly')
        except:
            log.info('Disclaimer Message is not present in this page, Can\'t able to automate')


