from selenium.webdriver.common.by import By

from utilites.BaseClass import BaseClass


class Test_SearchResult(BaseClass):
    def test_tabledata(self):
        log = self.get_logger()
        tabel_header = self.driver.find_elements(By.XPATH, "(//table[contains(@class,'views-table')]/thead/tr/th)")
        count = len(tabel_header)
        for i in range(count):
            j = str(i + 1)
            data = self.driver.find_element(By.XPATH,
                                                   "(//table[contains(@class,'views-table')]/thead/tr/th)[" + j + "]")
            assert data.is_displayed(),'Title, Business, Location, Site, Date Posted columns are not  displayed properly'
        log.info('Title, Business, Location, Site, Date Posted columns are displayed properly')


    def test_tabledataSorting(self):

        log = self.get_logger()
        before_sorting = []
        after_sorting = []
        data1 = self.driver.find_elements(By.XPATH, '//tbody/tr[1]/td')
        for d in data1:
            value = d.text
            before_sorting.append(value)
        log.info(before_sorting)
        table_header = self.driver.find_elements(By.XPATH, "(//table[contains(@class,'views-table')]/thead/tr/th)")
        count = len(table_header)
        for i in range(count):
            j = str(i + 1)
            data = self.driver.find_element(By.XPATH,
                                            "(//table[contains(@class,'views-table')]/thead/tr/th/a)[" + j + "]")
            self.driver.execute_script("arguments[0].click();", data)
        data2 = self.driver.find_elements(By.XPATH, '//tbody/tr[1]/td')
        for d in data2:
            value1 = d.text
            after_sorting.append(value1)
        log.info(after_sorting)
        assert not before_sorting == after_sorting, 'Sorting is not working properly'
        log.info('Sorting is working for all the columns')




