from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By

from utilites.BaseClass import BaseClass



class Test_SearchCount(BaseClass):
    def test_Searchcount(self):
        global total_jobs
        log = self.get_logger()
        search_count = self.driver.find_element(By.CSS_SELECTOR, '[class="search_count"]')
        assert search_count.is_displayed(),'Search Results (count) is not displayed'
        log.info('Search Results (count) is displayed properly')
        count =search_count.text

        next_button = self.driver.find_element(By.CSS_SELECTOR, '[title="Go to next page"]').is_displayed()
        while(next_button):
            try:
                total_jobs = len(self.driver.find_elements(By.XPATH, '//tbody/tr'))

                next_button = self.driver.find_element(By.CSS_SELECTOR, '[title="Go to next page"]')
                self.driver.execute_script("arguments[0].click();", next_button)
                log.info('next button')
            except NoSuchElementException as exc:
                log.info(exc)
                log.info('All Pages are counted')
            total_jobs += total_jobs

        log.info(total_jobs)
        assert total_jobs in count,'Search count result is not correct'
        log.info('Search count result is correct')







