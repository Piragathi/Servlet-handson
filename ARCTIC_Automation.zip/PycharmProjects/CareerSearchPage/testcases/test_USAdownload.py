import time

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait

from utilites.BaseClass import BaseClass


class Test_USAdownload(BaseClass):
    def test_USAdownlod(self):
        log = self.get_logger()
        Location_button = self.driver.find_element(By.XPATH,"//button[@type='button']/span[text()='Location']")
        Location_button.click()
        countries = self.driver.find_elements(By.XPATH,"//button[@type='button']/span[text()='Location']//parent::button/following-sibling::div/ul/li/label/input")
        for country in countries:
            value =country.get_attribute('title')
            if value == "USA":
                self.driver.execute_script("arguments[0].click();",country)
                break

        self.driver.find_element(By.CSS_SELECTOR,'[id="edit-submit-career-search--2"]').click()
        time.sleep(2)
        download = self.driver.find_element(By.XPATH,"//a[text()='Download']")
        assert download.is_displayed(),'Download button is not display'
        log.info('Download button is displayed properly')
        wait = WebDriverWait(self.driver, 3)
        wait.until(expected_conditions.element_to_be_clickable(download))
        log.info('Download button is clickable')





