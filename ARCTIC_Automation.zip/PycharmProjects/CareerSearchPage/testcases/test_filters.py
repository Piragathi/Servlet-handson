from selenium.webdriver.common.by import By
from datetime import date
from utilites.BaseClass import BaseClass


class Test_Filters(BaseClass):
    def test_Validate_Division(self):
        log = self.get_logger()
        list = ['CTS(633)','Novartis Technical Operations(580)']
        value = len(list)
        value1 = str(value)
        Division = self.driver.find_element(By.XPATH,"//span[normalize-space()='Division']")
        self.driver.execute_script("arguments[0].click();", Division)
        options = self.driver.find_elements(By.XPATH,
                                              "//button[@type='button']/span[text()='Division']//parent::button/following-sibling::div/ul/li/label/input")
        for i in options:
            value = i.get_attribute('title')
            for j in list:
                if value == j:
                    self.driver.execute_script("arguments[0].click();", i)
                    break
        Division_button = self.driver.find_element(By.XPATH, "(//button[@type='button']/span)[4]")
        After_selection =Division_button.text
        assert value1 in After_selection,'Division filter is not working properly'
        log.info('Division filter count is working properly')

    def test_Date_Posted(self):
        log = self.get_logger()
        Date_Posted = self.driver.find_element(By.CSS_SELECTOR,'[class="date_posted"]')
        self.driver.execute_script("arguments[0].click();", Date_Posted)
        options = self.driver.find_elements(By.CSS_SELECTOR,'[class="form-item-field-job-posted-date list-group open_posted"] li a')

        for i in options:
            value = i.text
            if value == 'Today':
                    self.driver.execute_script("arguments[0].click();", i)
                    break
        date_column = self.driver.find_element(By.XPATH,'(//td[contains(@class,"views-field-field-job-posted-date")])[1]')
        filtered_date = date_column.text
        today = date.today()
        current_date = today.strftime("%d %b %Y")
        log.info(filtered_date)
        log.info(current_date)
        assert filtered_date == current_date, 'Today\'s date  & filtered date  is not matching properly'
        log.info('Today\'s date  & filtered date  is  matching properly')





