import time

from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By

from utilites.BaseClass import BaseClass


class Test_Jobtitle(BaseClass):
    def test_jobTitle(self):
        log = self.get_logger()

        job_titles = self.driver.find_elements(By.CSS_SELECTOR, "td[class*='views-field'] a")
        total_count = len(job_titles)
        for i in range(total_count):
            j = str(i + 1)
            try:
                title = self.driver.find_element(By.XPATH,
                                             "(//a[contains(@href,'job-details')])[" + j + "]")
                self.driver.execute_script("arguments[0].click();", title)
                jobpage_url = self.driver.current_url
                assert 'job-details' in jobpage_url,' job title is not navigated to details page of the job'

                time.sleep(1)
            except NoSuchElementException as exc:
                log.info(exc)
            self.driver.back()
        log.info('job title is navigated to details page of the job')