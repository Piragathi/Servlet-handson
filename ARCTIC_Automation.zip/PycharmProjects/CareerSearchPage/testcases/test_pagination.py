import time

from selenium.webdriver.common.by import By

from utilites.BaseClass import BaseClass


class Test_pagination(BaseClass):
    def test_pagination(self):
        log = self.get_logger()

        pagination = self.driver.find_elements(By.CSS_SELECTOR, 'ul[class="pagination js-pager__items"] li a')
        count = len(pagination)
        for i in range(count):
            j = str(i + 1)
            page= self.driver.find_element(By.XPATH,
                                                "(//ul[@class='pagination js-pager__items']/li /a)[" + j + "]")
            self.driver.execute_script("arguments[0].click();", page)
            time.sleep(2)
            total_jobs =len(self.driver.find_elements(By.XPATH,'//tbody/tr'))
            assert total_jobs == 10
        log.info("Pagination is working properly & it having 10 jobs per page")


