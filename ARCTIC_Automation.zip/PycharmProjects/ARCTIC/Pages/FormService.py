from TestData.config import TestData
from Pages.BasePage import BasePage
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

class FormService(BasePage):
    def __init__(self,driver):
        super().__init__(driver)

    Subscribe = (By.XPATH, "//a[@class='we-mega-menu-li'] [normalize-space()='Subscribe']")
    ThirdLevel_Breadcrumbs = (By.CSS_SELECTOR,'li[class="breadcrumb-item"] a[href="/news/stay-up-to-date"]')
    First_Name = (By.ID,'edit-f-name')
    Last_Name = (By.ID,'edit-l-name')
    Email =(By.ID,'edit-email')
    Phone_num =(By.ID,'edit-phone-phone')
    Employer =(By.ID,'edit-work-name')
    Occupation =(By.ID,'edit-work-title')
    Location =(By.ID,'edit-country-country')
    Agree_Checkbox =(By.ID,'edit-accept-privacy-policy')
    Submit_button = (By.ID,'edit-actions-submit')
    Subscribe_Checkbox = (By.ID,'edit-subscribe')
    Unsubscribe_Checkbox = (By.ID,'edit-unsubscribe')
    PublicOrdeFrorm_Checkbox = (By.ID,'edit-publication-order-form')
    disable_unsubscribe_checkbox = (By.XPATH,'//div[contains(@class,"unsubscribe form-disabled")]')
    Language = (By.XPATH,'//span[normalize-space()="Language"]')
    English_Language = (By.XPATH,'//input[@checked="checked"]')
    Error_Message = (By.CSS_SELECTOR,'div[aria-label="Error message"]')
    SelectCountry = (By.CSS_SELECTOR,'[class="iti__selected-flag"]')
    country_code = (By.XPATH,'//ul[@id="country-listbox"]/li/span[@class="iti__dial-code"]')
    Publication_dropdown = (By.XPATH,'//select[contains(@id,"publication-name")]')
    Quantity = (By.XPATH,'//input[contains(@id,"quantity")]')
    Remove_button = (By.XPATH,'//input[contains(@id,"remove")]')
    Add_Another_Publication = (By.CSS_SELECTOR,'input[value="Add another Publication"]')
    Street_Address = (By.ID,'edit-address-address')
    City = (By.ID,'edit-address-city')
    Postal_Code = (By.ID,'edit-address-postal-code')
    Country = (By.ID,'edit-address-country')
    

    def click_element(self,element):
        self.jse_click(element)

    def click_News(self):
        self.Action(self.News)

    def Verify_Isdisplayed(self,element):
        return self.display(element)

    def BreadCrumbs_Isdisplayed(self):
        return self.display_elements(self.BreadCrumbs)

    def Verify_ThirdLevel_Breadcrumbs(self):
        return self.get_cssProperty(self.ThirdLevel_Breadcrumbs,TestData.property_color)

    def Verify_elements(self):
        elements = (self.First_Name,self.Last_Name,self.Email,self.Phone_num,self.Employer,self.Occupation,self.Location,self.Agree_Checkbox,self.Submit_button)
        for locator in elements:
            assert self.driver.find_element(*locator).is_displayed()
            return True

    def PublicationOrder_Isenabled(self):
        return self.Checkbox_Enable(self.PublicOrdeFrorm_Checkbox)

    def checkbox_Isdisabled(self,element):
        return self.Checkbox_Enable(element)

    def Language_displayed(self):
        return self.display(self.Language)

    def English_Checkbox_Selected(self):
        return self.Checkbox_Selected(self.English_Language)

    def element_sendkeys(self,element,value):
        return self.SendKeys(element,value)

    def select_Options(self,elements,code):
        options = self.findElements(elements)
        for i in options:
            value = i.text
            if code == value:
                self.driver.execute_script("arguments[0].click();",i)
                break
        
    def select_element(self,locators,value):
        dropdown = Select(self.driver.find_element(*locators))
        dropdown.select_by_value(value)

    def Verify_PublicationElements(self):
        elements = (self.Publication_dropdown,self.Quantity,self.Remove_button,self.Add_Another_Publication,self.Submit_button,self.Street_Address,self.City,self.Postal_Code,self.Country)
        for locator in elements:
            assert self.driver.find_element(*locator).is_displayed()
            return True

    
