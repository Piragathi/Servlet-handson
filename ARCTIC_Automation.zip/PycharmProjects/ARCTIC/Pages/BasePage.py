from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.color import Color
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By


class BasePage():
    def __init__(self, driver):
        self.driver = driver

    Megamenu = (By.XPATH,'//li[@class="nav-item menu"]/button[contains(@class,"nav-link")]')
    News = (By.XPATH, "(//li[contains(@class,'dropdown-menu')]/a[@href='/news'])")
    Pattern = (By.CSS_SELECTOR,'div[class="background_stripe"]')
    BreadCrumbs = (By.CSS_SELECTOR,'ol[class="breadcrumb"] li a')

    def display(self,locator):
         isDisplayed = self.driver.find_element(*locator).is_displayed()
         return isDisplayed

    def get_cssProperty(self,locator,property):
        Value_of_css = self.driver.find_element(*locator).value_of_css_property(property)
        hex = Color.from_string(Value_of_css).hex
        return hex

    def display_elements(self,locator):
        elements = self.driver.find_elements(*locator)
        for element in elements:
            assert element.is_displayed()
        return True

    def get_elementsLength(self,locator):
        Size = len(self.driver.find_elements(*locator))
        return Size

    def findElements(self,locator):
        return self.driver.find_elements(*locator)

    def get_currentURL(self):
        return self.driver.current_url

    def jse_click(self,locator):
        element = self.driver.find_element(*locator)
        self.driver.execute_script("arguments[0].click();",element)

    def click(self,locator):
        self.driver.find_element(*locator).click()


    def get_text(self,locator):
        return self.driver.find_element(*locator).text

    def element_clickable(self,locator):
        wait = WebDriverWait(self.driver, 5)
        wait.until(expected_conditions.element_to_be_clickable(locator))
        return bool(wait)

    def Action(self,locator):
        action = ActionChains(self.driver)
        action.move_to_element(self.driver.find_element(*locator)).perform()

    def Checkbox_Enable(self,locator):
        return self.driver.find_element(*locator).is_enabled()

    def Checkbox_Selected(self,locator):
        return self.driver.find_element(*locator).is_selected()


    def SendKeys(self,locator,value):
        self.driver.find_element(*locator).send_keys(value)

    
    def getPageTitle(self):
        return self.driver.title

    def getText(self,locator):
         return self.driver.find_element(*locator).text

    def getattributeValue(self,locator,value):
        return self.driver.find_element(*locator).get_attribute(value)
 