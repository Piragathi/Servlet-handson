from selenium.webdriver.common.by import By

from Pages.BasePage import BasePage



class CareersLandingPage(BasePage):
    def __init__(self,driver):
        super().__init__(driver)

    Megamenu = (By.XPATH,'//li[@class="nav-item menu"]/button[contains(@class,"nav-link")]')
    Careers = (By.XPATH, "//li[contains(@class,'dropdown-menu')]/a[@href='/careers']")
    Header_image = (By.XPATH, '(//div[contains(@class,"field--name-field-image")]//img[@class="img img-fluid"])[1]')
    Hero_Text = (By.XPATH,'(//div[@class="carousel_inner--wrapper  "])[1]')
    Search_textbox = (By.CSS_SELECTOR, 'input[placeholder="Search Job"]')
    Function_button = (By.XPATH,'//button/span[text()="Function"]')
    Location_button = (By.XPATH, '//button/span[text()="Location"]')
    Search_Button = (By.CSS_SELECTOR, '[id="edit-submit-career-search"]')
    Title = (By.CSS_SELECTOR,'[class="title"]')
    contries = (By.XPATH,"//button/span[text()='Location']//parent::button/following-sibling::div/ul/li/label/input")
    Fields = (By.XPATH,"//button/span[text()='Function']//parent::button/following-sibling::div/ul/li/label/input")
    afterSelection_Locationbutton = (By.XPATH, "(//button[@type='button']/span)[3]")
    afterSelection_Functionbutton = (By.XPATH, "(//button[@type='button']/span)[2]")
    applied_filters = (By.XPATH,'//div[@class="query-attribute"]')


    def click_element(self,element):
        self.jse_click(element)

    def Verify_HeaderImage(self):
        return self.display(self.Header_image)

    def Verify_HeroText(self):
        return self.display(self.Hero_Text)

    def Verify_SearchTextbox(self):
        return self.display(self.Search_textbox)

    def Verify_Function_button(self):
        return self.display(self.Function_button)

    def Verify_Location_button(self):
        return self.display(self.Location_button)

    def Verify_Search_button(self):
        return self.display(self.Search_Button)

    def Verify_Title(self):
        return self.display(self.Title)

    def select_Options(self,list,categories):
        value = len(list)
        count = str(value)
        options = self.findElements(categories)
        for i in options:
            value = i.get_attribute('title')
            for j in list:
                if value == j:
                    self.driver.execute_script("arguments[0].click();",i)
                    break
        return count

    def getText_Locationbutton(self):
        return self.get_text(self.afterSelection_Locationbutton)


    def getText_Functionbutton(self):
        return self.get_text(self.afterSelection_Functionbutton)

    def Verify_appliedFilters_Isdisplayed(self):
        return self.display_elements(self.applied_filters)





