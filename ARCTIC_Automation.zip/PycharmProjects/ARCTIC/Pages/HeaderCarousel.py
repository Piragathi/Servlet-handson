from selenium.webdriver.common.by import By

from Pages.BasePage import BasePage
from TestData.config import TestData


class HeaderCarousel(BasePage):
    def __init__(self,driver):
        super().__init__(driver)


    Pagination_dots = (By.CSS_SELECTOR,"ol[class='carousel-indicators'] li")
    Active_paginationDots = (By.XPATH, "//ol[@class='carousel-indicators']/li[@class= 'active']")

    def Pagination_Method(self,pagination_length):
        for i in range(pagination_length):
            j = str(i + 1)
            page = self.driver.find_element(By.XPATH,"(//ol[@class='carousel-indicators']/li)[" + j + "]")
            self.driver.execute_script("arguments[0].click();", page)
            color = self.get_cssProperty(self.Active_paginationDots,TestData.property)
            assert color == TestData.PaginationDot_color
        return True
