import time

from selenium.webdriver.common.by import By
from Pages.BasePage import BasePage
from TestData.config import TestData


class NovartisGlobalPipeline(BasePage):
    def __init__(self,driver):
        super().__init__(driver)

    Research_development = (By.CSS_SELECTOR, '[href="/news/media-library"]')
    Novartis_Pipeline = (By.XPATH, '(//a[@href="/research-development/novartis-pipeline"])[2]')
    Page_title = (By.XPATH,"//h1[text()='Novartis Pipeline']")
    Intro_text = (By.XPATH,"//h1[text()='Novartis Pipeline']//parent::div/p")
    Indication_tag = (By.CSS_SELECTOR, '[class="main-indication"]')
    Search_textbox = (By.XPATH, "//input[contains(@id,'edit-search')]")
    Search_button = (By.ID,'edit-submit-compounds-list')
    Filters_tag = (By.XPATH, "//select[contains(@id,'edit-field')]/following-sibling::div[@class='ms-options-wrap']/button")
    Pagination = (By.XPATH,"//ul[contains(@class,'pagination')]")
    Pagination_num = (By.XPATH, '//li[@class="page-item "] [normalize-space()="4"]/a')
    Breadcrumbs = (By.CSS_SELECTOR, 'ol[class="breadcrumb"] li')
    first_level = (By.XPATH, '//li[@class="breadcrumb-item"]/a[normalize-space()="Home"]')
    second_level = (By.XPATH, '//li[@class="breadcrumb-item"]/a[normalize-space()="Research & Development"]')
    ThirdLevel_breadcrumb = (By.XPATH,'//li[@class="breadcrumb-item"]/a[normalize-space()="Novartis Pipeline"]')
    CurrentPage = (By.CSS_SELECTOR, '[class="page-item active"] span')
    Forwardbutton = (By.CSS_SELECTOR, '[title="Go to next page"]')
    Backwardbutton = (By.CSS_SELECTOR, '[title="Go to previous page"]')
    Error_Msg = (By.CSS_SELECTOR,'div[class="view-empty"]')
    Search_Results = (By.CSS_SELECTOR,'[class="pipeline-main-wrapper"]')
    Legend = (By.XPATH,'//div[@class="content"]/div[text()="Legend"]')
    Disclaimer = (By.XPATH, '//div[@class="content"]/div[text()="Disclaimer"]')
    Therapeutic_Area = (By.XPATH,'(//button[@type="button"])[2]')
    AfterSelection_TherapeuticArea = (By.XPATH, '//span[contains(text(),"Therapeutic")]')
    TherapeuticArea_Options = (By.XPATH,'//span[contains(text(),"Therapeutic Area")]/../following-sibling::div/ul/li/label/input')
    Selcted_FilterTag = (By.CSS_SELECTOR,'[class="query-attribute"]')
    Development_Phase = (By.XPATH,'//span[text()="Development Phase"]/parent::button')
    DevelopmentPhase_Options = (By.XPATH, '//span[contains(text(),"Development Phase")]/../following-sibling::div/ul/li/label/input')
    AfterSelection_Development = (By.XPATH, '//span[contains(text(),"Development")]')
    Filling_Date = (By.XPATH, '//span[text()="Filing Date"]/parent::button')
    FilingDate_Options = (By.XPATH, '//span[contains(text(),"Filing Date")]/../following-sibling::div/ul/li/label/input')
    AfterSelection_FilingDate = (By.XPATH, '//span[contains(text(),"Filing")]')
    Indication_Name = (By.XPATH, '//span[text()="Indication Name"]/parent::button')
    IndicationName_Options = (By.XPATH, '//span[contains(text(),"Indication Name")]/../following-sibling::div/ul/li/label/input')
    AfterSelection_IndicationName = (By.XPATH, '//span[contains(text(),"Indication")]')
    ClearAll = (By.CSS_SELECTOR,'[class="clear-button"]')


    def click_ResearchDevelopment(self):
        self.Action(self.Research_development)

    def breadcrumbs(self,element):
        self.jse_click(element)
        time.sleep(2)
        return self.driver.current_url

    def arrowButtons(self,element):
        values = []
        initailpagno = int(self.get_text(self.CurrentPage))
        self.jse_click(element)
        current_no = int(self.get_text(self.CurrentPage))
        values.append(initailpagno)
        values.append(current_no)
        return values

    def select_Options(self,list,categories,filtertype):
        value = len(list)
        count = str(value)
        options = len(self.findElements(categories))
        for i in range(options):
            j = str(i + 1)
            page = self.driver.find_element(By.XPATH,
                                            "(//span[contains(text(),'" + filtertype + "')]/../following-sibling::div/ul/li/label/input)[" + j + "]")

            title = page.get_attribute('title')
            for k in list:
                if title == k:
                    self.driver.execute_script("arguments[0].click();",page)
                    time.sleep(3)
                self.jse_click(self.Therapeutic_Area)

        return count

    def verify_OptionSelected(self,list):
        self.click(self.Therapeutic_Area)
        time.sleep(2)
        for i in list:

            locator = (By.XPATH,"//span[contains(text(),'Therapeutic Area')]/../following-sibling::div/ul/li/label/input[@title='"+ i +"']")
            assert self.Checkbox_Selected(locator)
            assert self.get_cssProperty(locator,TestData.property) == TestData.Therapeutic_Color


    def verify_SelectedFilterTagIsPresent(self,list):
        self.click(self.Therapeutic_Area)
        filters = self.findElements(self.Selcted_FilterTag)
        for i in range(1):
            for filter in filters:
                Tags = filter.text
                assert list[i] in Tags
                break


    def verify_OptionSelectedDevPhase(self,list):
        self.click(self.Therapeutic_Area)
        time.sleep(2)
        for i in list:

            locator = (By.XPATH,"//span[contains(text(),'Development Phase')]/../following-sibling::div/ul/li/label/input[@title='"+ i +"']")
            assert self.Checkbox_Selected(locator)
            assert self.get_cssProperty(locator,TestData.property) == TestData.Therapeutic_Color

    def verify_OptionSelectedFilingDate(self, list):
        self.click(self.Therapeutic_Area)
        time.sleep(2)
        for i in list:
            locator = (By.XPATH,
                       "//span[contains(text(),'Filing Date')]/../following-sibling::div/ul/li/label/input[@title='" + i + "']")
            assert self.Checkbox_Selected(locator)
            assert self.get_cssProperty(locator, TestData.property) == TestData.Therapeutic_Color

    def verify_OptionSelectedIndicationName(self, list):
        self.click(self.Therapeutic_Area)
        time.sleep(2)
        for i in list:
            locator = (By.XPATH,
                       "//span[contains(text(),'Indication Name')]/../following-sibling::div/ul/li/label/input[@title='" + i + "']")
            assert self.Checkbox_Selected(locator)
            assert self.get_cssProperty(locator, TestData.property) in TestData.Indication_color

    def check_tagsIspresent(self):

        try:
             self.display_elements(self.Selcted_FilterTag)
        except:
            print('clear All field is working properly')











