import time

from TestData.config import TestData
from Tests.BaseTest import BaseTest

class Test_CareersLandingPage_ARC_2673(BaseTest):
    

    def test_careers_Setup(self):

        self.careers.click_element(self.careers.Megamenu)
        self.careers.click_element(self.careers.Careers)
        time.sleep(3)

    def test_CareersImage_HeroText(self):

        assert self.careers.Verify_HeaderImage()
        self.log.info('Header Image is displayed properly')
        assert self.careers.Verify_HeroText()
        self.log.info('Hero Text is displayed properly')

    def test_Featured_Stripes(self):

        assert self.careers.Verify_SearchTextbox()
        self.log.info('Search TextBox is displayed properly')
        assert self.careers.Verify_Function_button()
        self.log.info('Function Dropdown is displayed properly')
        assert self.careers.Verify_Location_button()
        self.log.info('Location Dropdown is displayed properly')
        assert self.careers.Verify_Search_button()
        self.log.info('Search button is displayed properly')
        assert self.careers.Verify_Title()
        self.log.info('Title is displayed properly')

    def test_Location(self):

        self.careers.click_element(self.careers.Location_button)
        count =self.careers.select_Options(TestData.country_list,self.careers.contries)
        Location_text = self.careers.getText_Locationbutton()
        assert count in Location_text
        self.log.info('Location filter count is working properly')

    def test_Function(self):

        self.careers.click_element(self.careers.Function_button)
        count = self.careers.select_Options(TestData.Field_list,self.careers.Fields)
        Function_text = self.careers.getText_Functionbutton()
        assert count in Function_text
        self.log.info('Function filter count is working properly')


    def test_filters(self):

        time.sleep(2)
        self.careers.click_element(self.careers.Search_Button)
        assert self.careers.Verify_appliedFilters_Isdisplayed()
        self.log.info('Filtered out the reqired items')

