import time


from TestData.config import TestData
from Tests.BaseTest import BaseTest


class Test_NovartisGlobalPipeline(BaseTest):

    def test_GlobalPipeline_Setup(self):

        self.pipeline.jse_click(self.pipeline.Megamenu)
        self.pipeline.click_ResearchDevelopment()
        self.pipeline.jse_click(self.pipeline.Novartis_Pipeline)
        time.sleep(3)


    def test_Verifications(self):

        assert self.pipeline.display(self.pipeline.Page_title)
        assert self.pipeline.display(self.pipeline.Intro_text)
        assert self.pipeline.get_cssProperty(self.pipeline.Indication_tag,TestData.Indication_property) in TestData.Indication_value
        assert self.pipeline.display(self.pipeline.Search_textbox)
        assert self.pipeline.display(self.pipeline.Search_button)
        assert self.pipeline.display_elements(self.pipeline.Filters_tag)
        assert self.pipeline.display(self.pipeline.Pagination)
        self.log.info('UI for the Global Pipeline Overview Page is displayed properly')

    def test_breadcrumbs(self):

        assert self.pipeline.display_elements(self.pipeline.Breadcrumbs)
        assert self.pipeline.get_cssProperty(self.pipeline.ThirdLevel_breadcrumb,TestData.property_color) == TestData.Third_level_breadcrumbColor
        self.log.info('ThirdLevel breadcrumb is greyed out')
        assert self.pipeline.breadcrumbs(self.pipeline.first_level) == TestData.HomePage_URL
        self.log.info('First Level breadcrumb is navigated to the Home Page.')
        self.driver.back()
        assert self.pipeline.breadcrumbs(self.pipeline.second_level) == TestData.Research_Development_URL
        self.log.info('Second Level breadcrumb is navigated to the Research and Development Page.')
        self.driver.back()

    def test_pagination(self):

        self.pipeline.jse_click(self.pipeline.Pagination_num)
        page_no =self.pipeline.arrowButtons(self.pipeline.Forwardbutton)
        assert page_no[0] < page_no[1]
        self.log.info('Forward button is working properly,It navigated to the respective forward page')
        page_no = self.pipeline.arrowButtons(self.pipeline.Backwardbutton)
        assert page_no[0] > page_no[1]
        self.log.info('Backward button is working properly,It navigated to the respective backward page')

    def test_invalidSearch(self):

        self.test_GlobalPipeline_Setup()
        self.pipeline.SendKeys(self.pipeline.Search_textbox,TestData.InvalidSearchData)
        self.pipeline.jse_click(self.pipeline.Search_button)
        time.sleep(3)
        assert self.pipeline.get_text(self.pipeline.Error_Msg) == TestData.Error_msg
        self.log.info('validation message as  "No Results found" is displayed properly')


    def test_ValidSearch(self):

        self.test_GlobalPipeline_Setup()
        self.pipeline.SendKeys(self.pipeline.Search_textbox, TestData.validSearchData)
        self.pipeline.jse_click(self.pipeline.Search_button)
        time.sleep(3)
        assert self.pipeline.display_elements(self.pipeline.Search_Results)
        self.log.info('Search results is displayed properly')

    def test_LegendDisclaimer(self):

        self.test_GlobalPipeline_Setup()
        self.pipeline.display(self.pipeline.Legend)
        self.pipeline.display(self.pipeline.Disclaimer)
        self.log.info('Legend and Disclaimer is displayed properly')

    def test_TherapeuticAreaFilter(self):

        self.test_GlobalPipeline_Setup()
        self.pipeline.click(self.pipeline.Therapeutic_Area)
        time.sleep(2)
        count = self.pipeline.select_Options(TestData.TherapeuticArea_List,self.pipeline.TherapeuticArea_Options,'Therapeutic Area')
        time.sleep(2)
        Therapeutic_text = self.pipeline.get_text(self.pipeline.AfterSelection_TherapeuticArea)
        assert count in Therapeutic_text
        self.log.info('Therapeutic Area filter count is working properly')
        self.pipeline.verify_OptionSelected(TestData.TherapeuticArea_List)
        self.pipeline.verify_SelectedFilterTagIsPresent(TestData.TherapeuticArea_List)
        self.log.info('Selected tags is displayed properly')


    def test_DevelopmentPhaseFilter(self):

        self.test_GlobalPipeline_Setup()
        self.pipeline.click(self.pipeline.Development_Phase)
        time.sleep(2)
        count = self.pipeline.select_Options(TestData.DevelopmentPhase_List, self.pipeline.DevelopmentPhase_Options,'Development Phase')
        time.sleep(2)
        DevelopmentPhase_text = self.pipeline.get_text(self.pipeline.AfterSelection_Development)
        assert count in DevelopmentPhase_text
        self.log.info('Development Phase filter count is working properly')
        self.pipeline.verify_OptionSelectedDevPhase(TestData.DevelopmentPhase_List)
        self.pipeline.verify_SelectedFilterTagIsPresent(TestData.DevelopmentPhase_List)
        self.log.info('Selected tags is displayed properly')

    def test_FillingDate(self):

        self.test_GlobalPipeline_Setup()
        self.pipeline.click(self.pipeline.Filling_Date)
        time.sleep(2)
        count = self.pipeline.select_Options(TestData.FilingDate_List, self.pipeline.FilingDate_Options,'Filing Date')
        time.sleep(2)
        FilingDate_text = self.pipeline.get_text(self.pipeline.AfterSelection_FilingDate)
        assert count in FilingDate_text
        self.log.info('Filing Date filter count is working properly')
        self.pipeline.verify_OptionSelectedFilingDate(TestData.FilingDate_List)
        self.pipeline.verify_SelectedFilterTagIsPresent(TestData.FilingDate_List)
        self.log.info('Selected tags is displayed properly')

    def test_IndicationName(self):

        self.test_GlobalPipeline_Setup()
        self.pipeline.click(self.pipeline.Indication_Name)
        time.sleep(2)
        count = self.pipeline.select_Options(TestData.Indication_List, self.pipeline.IndicationName_Options, 'Indication Name')
        time.sleep(2)
        FilingDate_text = self.pipeline.get_text(self.pipeline.AfterSelection_IndicationName)
        assert count in FilingDate_text
        self.log.info('Filing Date filter count is working properly')
        self.pipeline.verify_OptionSelectedIndicationName(TestData.Indication_List)
        self.pipeline.verify_SelectedFilterTagIsPresent(TestData.Indication_List)
        self.log.info('Selected tags is displayed properly')

    def test_clearAll(self):

        self.pipeline.click(self.pipeline.ClearAll)
        self.pipeline.check_tagsIspresent()

























