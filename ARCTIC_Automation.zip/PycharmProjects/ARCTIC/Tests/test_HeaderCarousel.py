from Tests.BaseTest import BaseTest

class Test_HeaderCarousel_ARC_2413(BaseTest):

    def test_corousel(self):

        try:
            assert self.header.display(self.header.Pagination_dots)
            length = self.header.get_elementsLength(self.header.Pagination_dots)
            self.header.Pagination_Method(length)

        except:
            self.log.info('Header Carousel is not present in the Home Page')


