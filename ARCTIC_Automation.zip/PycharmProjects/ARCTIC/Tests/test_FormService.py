import time
from Tests.BaseTest import BaseTest
from TestData.config import TestData



class Test_FormService_ARC_2702(BaseTest):
    
    def test_FormService_Setup(self):

        self.form.click_element(self.form.Megamenu)
        self.form.click_News()
        self.form.click_element(self.form.Subscribe)
        time.sleep(3)

    def test_Verifications(self):

        assert self.form.Verify_Isdisplayed(self.form.Pattern)
        self.log.info('Pattern is displayed properly')
        assert self.form.BreadCrumbs_Isdisplayed()
        assert self.form.Verify_ThirdLevel_Breadcrumbs() == TestData.Third_level_breadcrumbColor
        self.log.info('Breadcrumbs is displayed properly & third level breadcrumbs is greyed out')
        assert self.form.Verify_elements()
        self.log.info('All fields are present')

    def test_Subscribe_Checkbox(self):

        self.form.click_element(self.form.Subscribe_Checkbox)
        assert self.form.PublicationOrder_Isenabled()
        self.log.info('Publication Order is enabled')
        assert not self.form.checkbox_Isdisabled(self.form.Unsubscribe_Checkbox)
        self.log.info('Unsubscribe checkbox is disabled')
        assert self.form.Language_displayed()
        self.log.info('Language field is displayed ')
        assert self.form.English_Checkbox_Selected()
        self.log.info('Default English is selected.')

    def test_Register_withMandatoryFields(self):

        self.form.element_sendkeys(self.form.First_Name,TestData.First_Name)
        self.form.element_sendkeys(self.form.Last_Name,TestData.Last_Name)
        self.form.element_sendkeys(self.form.Email,TestData.Email)
        self.form.click_element(self.form.Agree_Checkbox)
        self.form.click_element(self.form.Submit_button)
        time.sleep(3)
        self.form.Verify_Isdisplayed(self.form.Error_Message)
        self.log.info('Error Message is displayed properly while submit with Mandatory fields')
        self.driver.back()
        time.sleep(2)

    def test_Register_withAllFields(self):

        self.form.click_element(self.form.SelectCountry)
        self.form.select_Options(self.form.country_code,TestData.code)
        self.form.element_sendkeys(self.form.Phone_num,TestData.number)
        self.form.element_sendkeys(self.form.Employer,TestData.Employer)
        self.form.element_sendkeys(self.form.Occupation,TestData.Occupation)
        self.form.select_element(self.form.Location,TestData.Location)
        self.form.click_element(self.form.Submit_button)
        time.sleep(3)
        self.form.Verify_Isdisplayed(self.form.Error_Message)
        self.log.info('Error Message is displayed properly while submit with all fields')

    def test_UnSubscribe_Checkbox(self):

        self.test_FormService_Setup()
        self.form.click_element(self.form.Unsubscribe_Checkbox)
        assert not self.form.checkbox_Isdisabled(self.form.Subscribe_Checkbox)
        self.log.info('subscribe checkbox is disabled')
        assert not self.form.checkbox_Isdisabled(self.form.PublicOrdeFrorm_Checkbox)
        self.log.info('Publication Order form checkbox is disabled')
        assert self.form.Verify_Isdisplayed(self.form.Email)
        assert self.form.Verify_Isdisplayed(self.form.Agree_Checkbox)
        assert self.form.Verify_Isdisplayed(self.form.Submit_button)
        self.log.info('Email,Agree checkbox and submit button is displaye properly')


    def test_Register_Unsubscribe(self):

        self.form.element_sendkeys(self.form.Email,TestData.Email)
        self.form.click_element(self.form.Agree_Checkbox)
        self.form.click_element(self.form.Submit_button)
        time.sleep(3)
        self.form.Verify_Isdisplayed(self.form.Error_Message)
        self.log.info('Error Message is displayed properly while submit in unsubscribe checkbox')


    def test_PublicationOrder_Checkbox(self):

        self.test_FormService_Setup()
        self.form.click_element(self.form.PublicOrdeFrorm_Checkbox)
        self.form.Verify_PublicationElements()
        self.log.info('All fields are present for the Publication Order checkbox')


    def test_Register_PublicationOrder(self):

        self.form.element_sendkeys(self.form.First_Name,TestData.First_Name)
        self.form.element_sendkeys(self.form.Last_Name,TestData.Last_Name)
        self.form.element_sendkeys(self.form.Email,TestData.Email)
        self.form.select_element(self.form.Publication_dropdown,TestData.Publication_value)
        self.form.element_sendkeys(self.form.Quantity,TestData.Quantity)
        self.form.element_sendkeys(self.form.Street_Address,TestData.Street_Address)
        self.form.element_sendkeys(self.form.City,TestData.City)
        self.form.element_sendkeys(self.form.Postal_Code,TestData.Postal_code)
        self.form.select_element(self.form.Location,TestData.Location)
        self.form.click_element(self.form.Agree_Checkbox)
        self.form.click_element(self.form.Submit_button)
        time.sleep(3)
        self.form.Verify_Isdisplayed(self.form.Error_Message)
        self.log.info('Error Message is displayed properly while submit with Mandatory fields in Publication Order')



    
        







        




    

        




        






               





