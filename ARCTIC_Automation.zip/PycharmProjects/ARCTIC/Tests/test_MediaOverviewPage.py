from Pages.MediaLibraryOverviewPage import MediaLibraryOverview
from TestData.config import TestData
from Tests.BaseTest import BaseTest
import time


class Test_MediaLibraryOverviewPage_ARC_2647(BaseTest):

    def test_MediaPage_Setup(self):

        self.media.click_element(self.media.Megamenu)
        self.media.click_News()
        self.media.click_element(self.media.MediaLibrary)
        time.sleep(3)

    def test_Verifications(self):

        assert self.media.Verify_Isdisplayed(self.media.Pattern)
        self.log.info('Pattern is displayed properly')
        assert self.media.getPageTitle() == TestData.Page_title
        self.log.info('Page Title is displayed properly')
        assert self.media.BreadCrumbs_Isdisplayed()
        assert self.media.Verify_BackgroundColor(self.media.ThirdLevel_Breadcrumbs,TestData.property_color) == TestData.Third_level_breadcrumbColor
        self.log.info('Breadcrumbs is displayed properly & third level breadcrumbs is greyed out')
        assert self.media.Verify_Isdisplayed(self.media.Default_contentView)
        self.log.info('Default content Pages are displayed in the Grid View')
        assert self.media.Verify_BackgroundColor(self.media.All_Field,TestData.property) == TestData.background_color
        self.log.info(' "All" menu is greyed out')


    def test_FirstLevelbreadcrumbs(self):

        self.media.click_element(self.media.Home_BreadCrumb)
        time.sleep(3)
        current_URL = self.media.get_currentURL()
        assert TestData.HomePage_URL == current_URL
        self.log.info('First Level Breadcrumb navigated to Home page')
        self.driver.back()

    def test_SecondLevelbreadcrumbs(self):

        self.media.click_element(self.media.News_BreadCrumb)
        time.sleep(2)
        current_URL = self.media.get_currentURL()
        assert TestData.News_URl == current_URL
        self.log.info('Second Level Breadcrumb navigated to Home page')
        self.driver.back()

    def test_Pagination(self):

        assert self.media.get_contentsLength() == 12
        pagination_length = self.media.get_Pagination()
        assert self.media.Pagination_Method(pagination_length)
        self.log.info("Pagination is working properly & it having 12 contents per page")

    def test_ListView(self):

        self.media.click_element(self.media.View_text)
        assert self.media.Verify_Isdisplayed(self.media.ListView)
        assert self.media.get_text(self.media.View_text) == 'Grid View'
        self.log.info('Media Library content Pages displayed on List View and text change as Grid view')

    
    def test_GridView(self):

        self.media.click_element(self.media.View_text)
        assert self.media.Verify_Isdisplayed(self.media.GridView)
        assert self.media.get_text(self.media.View_text) == 'List View'
        self.log.info('Media Library content Pages displayed on Grid View and text change as List view')


    def test_clickedMenu_backgroundColor(self):

        self.test_MediaPage_Setup()
        self.media.click_element(self.media.Document_Menu)
        time.sleep(3)
        assert self.media.Verify_BackgroundColor(self.media.Document_Menu,TestData.property) == TestData.background_color
        self.log.info('clicked Document Menu is greyed out')


    def test_forwardArrow(self):

        self.test_MediaPage_Setup()
        self.media.click_element(self.media.pagination_num)
        initailpagno = int(self.media.get_text(self.media.currentPage))

        self.media.click_element(self.media.forwardbutton)

        current_no = int(self.media.get_text(self.media.currentPage))
        assert initailpagno < current_no
        self.log.info('Forward button is working,It navigated to the respective forward page')


    def test_backward_arrow(self):

        initailpagno = int(self.media.get_text(self.media.currentPage))

        self.media.click_element(self.media.Backwardbutton)
        current_no = int(self.media.get_text(self.media.currentPage))
        
        assert initailpagno > current_no
        self.log.info('Backward button is working,It navigated to the respective backward page')

    

