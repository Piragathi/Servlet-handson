import time

from selenium.webdriver.common.by import By

from utilites.BaseClass import BaseClass


class Test_breadcrumbs(BaseClass):
    def test_breadcrumbs(self):
        log = self.get_logger()
        HomePage_url = 'https://prod1.novartis.com/'
        CareersPage_url  ='https://prod1.novartis.com/careers'
        CareersSearchPage_url ='https://prod1.novartis.com/careers/career-search'
        Url =[HomePage_url,CareersPage_url,CareersSearchPage_url]

        job_title = self.driver.find_element(By.XPATH, "(//td[contains(@class,'views-field')]/a)[1]")
        self.driver.execute_script("arguments[0].click();", job_title)
        items= self.driver.find_elements(By.XPATH, "//li[@class='breadcrumb-item']/a")
        total_count = len(items)

        for i in range(total_count -1 ):
            j = str(i+1)
            breadcrumbs = self.driver.find_element(By.XPATH,
                                             "(//li[@class='breadcrumb-item']/a)[" + j + "]")
            self.driver.execute_script("arguments[0].click();", breadcrumbs)
            time.sleep(2)
            current_Url = self.driver.current_url
            for i in Url:
               log.info(i)

            self.driver.back()
        log.info('First level breadcrumb is working properly')
        log.info('Second Level breadcrumbs is working properly')
        log.info('Third level breadcrumbs is working properly')











