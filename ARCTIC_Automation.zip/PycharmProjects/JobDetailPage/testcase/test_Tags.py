from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait

from utilites.BaseClass import BaseClass


class Test_Tags(BaseClass):
    def test_jobTag(self):
        log = self.get_logger()
        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        job_title = self.driver.find_element(By.XPATH, "(//td[contains(@class,'views-field')]/a)[1]")
        self.driver.execute_script("arguments[0].click();", job_title)
        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        tags = self.driver.find_elements(By.CSS_SELECTOR, '[class*="views-field-field-job-tags-1"] a')

        for tag in tags:
            assert tag.is_displayed(), 'Tags are not displayed properly'
            wait = WebDriverWait(self.driver, 3)
            assert wait.until(expected_conditions.element_to_be_clickable(tag))

        log.info('Tags are displayed properly on all job detail pages')
        log.info('Tags are clickable')
