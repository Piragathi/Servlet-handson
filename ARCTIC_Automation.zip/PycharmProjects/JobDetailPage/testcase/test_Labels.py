import os
import time

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait

from utilites.BaseClass import BaseClass


class Test_Labels(BaseClass):
    def test_joblabels(self):
        log = self.get_logger()
        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        job_title = self.driver.find_element(By.XPATH, "(//td[contains(@class,'views-field')]/a)[1]")
        self.driver.execute_script("arguments[0].click();", job_title)
        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        Print =self.driver.find_element(By.CSS_SELECTOR, 'li[class="print"] a')
        self.driver.execute_script("arguments[0].click();", Print)
        time.sleep(2)
        url = self.driver.current_url

        assert 'print' in url, 'print button is not working'
        log.info('Print button is working properly')
        self.driver.back()
        time.sleep(2)
        Save =self.driver.find_element(By.CSS_SELECTOR, 'li[class="pdf"] a')
        wait = WebDriverWait(self.driver, 3)
        assert wait.until(expected_conditions.element_to_be_clickable(Save)),'Save button is not working properly'
        log.info('Save button is working properly')
















