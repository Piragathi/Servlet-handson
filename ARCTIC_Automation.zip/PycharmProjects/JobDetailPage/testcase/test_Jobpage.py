import time

from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By

from utilites.BaseClass import BaseClass


class Test_JobPage(BaseClass):
    def test_Pattern_breadcrumbs(self):
        log = self.get_logger()

        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        job_title = self.driver.find_element(By.XPATH, "(//td[contains(@class,'views-field')]/a)[1]")
        self.driver.execute_script("arguments[0].click();", job_title)
        time.sleep(2)
        assert self.driver.find_element(By.CSS_SELECTOR,
                                       '[class="background_stripe"]').is_displayed(), 'Pattern is not displayed properly'

        assert self.driver.find_element(By.CSS_SELECTOR,
                                       '[class="breadcrumb"]').is_displayed(), 'Breadcrumbs are not displayed Properly'


        log.info('Patterns are displayed properly on all job detail pages')
        log.info('Breadcrumbs are displayed properly on all job detail pages')




    def test_Job_title_Id_Location_Date(self):
        log = self.get_logger()
        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        job_titles = self.driver.find_elements(By.CSS_SELECTOR, "td[class*='views-field'] a")
        total_count = len(job_titles)
        for i in range(total_count):
            j = str(i + 1)
            title = self.driver.find_element(By.XPATH,
                                             "(//td[@class='views-field views-field-field-job-title']/a)[" + j + "]")
            self.driver.execute_script("arguments[0].click();", title)
            time.sleep(2)
            assert self.driver.find_element(By.CSS_SELECTOR,
                                            '[class="title"]').is_displayed(), 'Job title is not displayed properly'

            jobs = self.driver.find_elements(By.CSS_SELECTOR, '[class="d-inline-block"]')

            for job in jobs[0:4]:
                assert job.is_displayed(), 'Job ID /Location / Date '
            self.driver.back()
        log.info('Titles are displayed properly on all job detail pages')
        log.info('Job ID, Job Date, Job Location are displayed properly on all job detail pages')

    def test_defaultImage(self):
        log = self.get_logger()
        job_titles = self.driver.find_elements(By.CSS_SELECTOR, "td[class*='views-field'] a")
        total_count = len(job_titles)
        for i in range(total_count):
            j = str(i + 1)
            title = self.driver.find_element(By.XPATH,
                                             "(//td[@class='views-field views-field-field-job-title']/a)[" + j + "]")

            self.driver.execute_script("arguments[0].click();", title)
            time.sleep(2)
            assert self.driver.find_element(By.CSS_SELECTOR,
                                       'img[src="https://prod1.novartis.com/themes/custom/nvs_arctic/patterns/images/careers-default-image.jpg"]').is_displayed(), 'Default Image is not displayed'

            job_snapshots = self.driver.find_elements(By.CSS_SELECTOR,
                                                 'div[class="field_job_snapshot"] [class="d-inline-block"]')
            for snapshot in job_snapshots:
                assert snapshot.is_displayed(), 'Job Id is not displayed properly'
            assert self.driver.find_element(By.CSS_SELECTOR,
                                       '[class="field_job_position_title "]').is_displayed(), 'Job Title is not displayed properly'

            buttons = self.driver.find_elements(By.CSS_SELECTOR,
                                           'div[class="field_job_snapshot"] [class="link_button button_text"]')
            for button in buttons:
                assert button.is_displayed(), 'Buttons is not displayed properly'

            self.driver.back()
        log.info('Default images are displayed properly on all job detail pages')
        log.info('Job title ,Job Id are present on all job detail pages inside the Image frame')
        log.info('Buttons are present on all job detail pages inside the Image frame')






