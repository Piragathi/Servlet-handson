import time

from selenium.webdriver.common.by import By

from utilites.BaseClass import BaseClass


class Test_Buttons(BaseClass):
    def test_buttons_popup(self):
        log = self.get_logger()
        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        job_title = self.driver.find_element(By.XPATH, "(//td[contains(@class,'views-field')]/a)[1]")
        self.driver.execute_script("arguments[0].click();", job_title)

        buttons = self.driver.find_elements(By.CSS_SELECTOR,
                                                'div[class="field_job_snapshot"] [class="link_button button_text"]')

        for button in buttons:
            self.driver.execute_script("arguments[0].click();", button)
            assert self.driver.find_element(By.CSS_SELECTOR, '[class*=external-link-popup-id-default]').is_displayed(),'Pop up is not displaying properly'
        log.info("Pop up are displayed properly on all job detail pages")




