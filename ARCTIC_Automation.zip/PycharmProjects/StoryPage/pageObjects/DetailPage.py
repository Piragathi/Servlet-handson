import time

from selenium.webdriver.common.by import By

from pageObjects.BasePage import BasePage


class DetailPage(BasePage):
    def __init__(self,driver):
        super().__init__(driver)

    contents = (By.CSS_SELECTOR, 'ul[class="whole-item"] li a')
    Righthandrail = (By.XPATH, '//div[@class="content"]/span')
    BreadCrumbs = (By.CSS_SELECTOR, 'ol[class="breadcrumb"]')
    buttons = (By.CSS_SELECTOR,'[class="pre_links"] a')
    socialMediaIcons = (By.XPATH,'//div[@class="content"]/span/a[contains(@class,"a2a_button")]')

    def Length_content(self):
        return self.get_elementsLength(DetailPage.contents)


    def Righthandrail_Verify(self):
        return self.display(DetailPage.Righthandrail)

    def Breadcrumbs_Verify(self):
        return self.display(DetailPage.BreadCrumbs)

    def Verify_PrintSave(self):
        return self.findElements(DetailPage.buttons)

    def socialMediaIcons_Verify(self):
        return self.element_clickable(DetailPage.socialMediaIcons)

    def detailPageMethod(self,length):
        for i in range(length):
            j = str(i + 1)
            page = self.driver.find_element(By.XPATH,"(//ul[@class='whole-item']/li/a)[" + j + "]")
            self.driver.execute_script("arguments[0].click();", page)
            assert DetailPage.Righthandrail_Verify(self)
            assert DetailPage.Breadcrumbs_Verify(self)
            self.driver.back()

    def detailPagebutton(self,length):
        for i in range(length):
            j = str(i + 1)
            page = self.driver.find_element(By.XPATH,"(//ul[@class='whole-item']/li/a)[" + j + "]")
            self.driver.execute_script("arguments[0].click();", page)
            Verify_PrintSave = DetailPage.Verify_PrintSave(self)
            self.driver.back()
            return Verify_PrintSave

    def SocialMediaIcons_clickable(self,length):
        for i in range(length):
            j = str(i + 1)
            page = self.driver.find_element(By.XPATH, "(//ul[@class='whole-item']/li/a)[" + j + "]")
            self.driver.execute_script("arguments[0].click();", page)
            links_clickable = self.socialMediaIcons_Verify()
            self.driver.back()
            return links_clickable



