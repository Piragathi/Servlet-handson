import time

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.color import Color
from selenium.webdriver.support.wait import WebDriverWait


class BasePage():
    def __init__(self, driver):
        self.driver = driver

    def display(self,locator):
         isDisplayed = self.driver.find_element(*locator).is_displayed()
         return isDisplayed

    def get_cssProperty(self,locator,property):
        Value_of_css = self.driver.find_element(*locator).value_of_css_property(property)
        hex = Color.from_string(Value_of_css).hex
        return hex

    def display_elements(self,locator):
        Menus = self.driver.find_elements(*locator)
        for menu in Menus:
            return menu.is_displayed()

    def get_elementsLength(self,locator):
        Size = len(self.driver.find_elements(*locator))
        return Size

    def findElements(self,locator):
        return self.driver.find_elements(*locator)

    def Pagination_Method(self,pagination_length):
        for i in range(pagination_length):
            j = str(i + 1)
            page = self.driver.find_element(By.XPATH,"(//ul[@class='pagination js-pager__items']/li /a)[" + j + "]")
            self.driver.execute_script("arguments[0].click();", page)
            time.sleep(2)

    def get_currentURL(self):
        return self.driver.current_url

    def jse_click(self,locator):
        element = self.driver.find_element(*locator)
        self.driver.execute_script("arguments[0].click();",element)

    def get_text(self,locator):
        return self.driver.find_element(*locator).text

    def element_clickable(self,locator):
        wait = WebDriverWait(self.driver, 5)
        wait.until(expected_conditions.element_to_be_clickable(locator))
        return bool(wait)
