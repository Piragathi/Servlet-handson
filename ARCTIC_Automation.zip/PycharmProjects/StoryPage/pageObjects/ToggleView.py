from selenium.webdriver.common.by import By

from pageObjects.BasePage import BasePage


class ToggleView(BasePage):

    def __init__(self,driver):
        super().__init__(driver)

    toggleView = (By.CSS_SELECTOR,'[class="toggle_over_view"]')
    ListView = (By.XPATH,'//div[contains(@class,"list_view")]')
    GridView = (By.XPATH, "//div[contains(@class,'grid_view')]")
    View_text =(By.XPATH,'//button[@class="toggle_text"]')


    def click_toggleView(self):
        return self.jse_click(ToggleView.toggleView)

    def Isdisplay_ListView(self):
        return self.display(ToggleView.ListView)

    def click_GridView(self):
        return self.jse_click(ToggleView.View_text)

    def Isdisplay_GridView(self):
        return self.display(ToggleView.GridView)

    def Isdisplay_ListViewText(self):
        return self.driver.find_element(*ToggleView.View_text).text

    def click_ListView(self):
        return self.jse_click(ToggleView.View_text)

    def Isdisplay_GridViewText(self):
        return self.driver.find_element(*ToggleView.View_text).text



