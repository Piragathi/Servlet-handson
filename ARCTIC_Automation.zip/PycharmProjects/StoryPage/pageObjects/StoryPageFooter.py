from selenium.webdriver.common.by import By

from pageObjects.BasePage import BasePage


class StoryPageFooter(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

    pagination_num = (By.XPATH, '//li[@class="page-item "] [normalize-space()="4"]/a')
    forwardbutton = (By.CSS_SELECTOR, '[title="Go to next page"]')
    currentPage = (By.CSS_SELECTOR, '[class="page-item active"] span')
    Backwardbutton = (By.CSS_SELECTOR, '[title="Go to previous page"]')

    def click_pgNo(self):
        return self.jse_click(StoryPageFooter.pagination_num)

    def getText_clickedPage(self):
        return self.get_text(StoryPageFooter.pagination_num)

    def click_forwardButton(self):
        return self.jse_click(StoryPageFooter.forwardbutton)

    def getText_currentPage(self):
        return self.get_text(StoryPageFooter.currentPage)

    def click_backwarddButton(self):
        return self.jse_click(StoryPageFooter.Backwardbutton)
