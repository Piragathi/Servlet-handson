from selenium.webdriver.common.by import By

from TestData.config import TestData
from pageObjects.BasePage import BasePage


class StoryPage(BasePage):
    def __init__(self,driver):
        super().__init__(driver)

    Novartis_Logo = (By.XPATH,'//img[contains(@class,"novartis-logo")]')
    Search_icon = (By.XPATH,'//button[@class="nav-link nav-link-"] [normalize-space()="Search"]')
    Mega_menu =  (By.XPATH,'//span[@class="nav-link nav-link-"] [normalize-space()="Menu"]')
    Pattern = (By.CSS_SELECTOR,'[class="background_stripe"]')
    All_Topic = (By.XPATH, "//a[normalize-space()='All Topics']")
    BreadCrumbs = (By.CSS_SELECTOR, 'ol[class="breadcrumb"]')
    Menus = (By.CSS_SELECTOR,'[class="item-list"] ul[id="block-storynavigation"] li')
    toggle_over_view_txt = (By.CSS_SELECTOR, '[class="toggle_text"]')
    toggle_over_view = (By.XPATH, "//div[contains(@class,'grid_view')]")
    contents = (By.CSS_SELECTOR,'ul[class="whole-item"] li a')
    Pagination = (By.CSS_SELECTOR, 'ul[class="pagination js-pager__items"] li a')
    Discovery_Menu = (By.XPATH,"//a[normalize-space()='Discovery']")
    Home_BreadCrumb = (By.XPATH,'//li[@class="breadcrumb-item"] [normalize-space()="Home"]')
    Media_Center = (By.XPATH,'//li[@class="breadcrumb-item"] [normalize-space()="Media Center"]')



    def Logo_Verify(self):
        return self.display(StoryPage.Novartis_Logo)

    def SearchIcon_Verify(self):
        return self.display(StoryPage.Search_icon)

    def Megamenu_Verify(self):
        return self.display(StoryPage.Mega_menu)

    def Pattern_Verify(self):
        return self.display(StoryPage.Pattern)

    def AllTopics_Verify(self):
        return self.get_cssProperty(StoryPage.All_Topic,TestData.property)

    def Breadcrumbs_Verify(self):
        return self.display(StoryPage.BreadCrumbs)

    def Menus_Verify(self):
        return self.display_elements(StoryPage.Menus)

    def ToggleText_Verify(self):
        Text =self.driver.find_element(*StoryPage.toggle_over_view_txt).text
        return Text

    def ToggleView_Verify(self):
        return self.display(StoryPage.toggle_over_view)

    def get_contentsLength(self):
        return self.get_elementsLength(StoryPage.contents)

    def get_Pagination(self):
        return self.get_elementsLength(StoryPage.Pagination)

    def pagination_method(self,page_len):
        return self.Pagination_Method(page_len)

    def click_discoveryMenu(self):
        return self.driver.find_element(*StoryPage.Discovery_Menu).click()

    def get_backgroundColor(self):
        return self.get_cssProperty(StoryPage.Discovery_Menu,TestData.property)

    def click_HomeBreadcrumbs(self):
        return self.driver.find_element(*StoryPage.Home_BreadCrumb).click()

    def click_MediaCenterBreadcrumbs(self):
        return self.driver.find_element(*StoryPage.Media_Center).click()

    def get_contents(self):
        return self.findElements(StoryPage.contents)
