class TestData():
    background_color = "#f1f1f1"
    property = "background-color"
    Text = "List View"
    HomePage_URL = "https://prod1.novartis.com/"
    StoryPage_URL = "https://prod1.novartis.com/stories"