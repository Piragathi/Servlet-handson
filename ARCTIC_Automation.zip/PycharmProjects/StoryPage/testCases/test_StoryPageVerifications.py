from TestData.config import TestData
from pageObjects.StoryPage import StoryPage
from utilities.BaseClass import BaseClass


class Test_StoryPageVerifications(BaseClass):
    def test_verifications(self):
        log = self.get_logger()
        storypage = StoryPage(self.driver)

        assert storypage.Logo_Verify()
        log.info('Novartis Logo is displayed properly')

        assert storypage.SearchIcon_Verify()
        log.info('Search Icon is displayed properly')

        assert storypage.Megamenu_Verify()
        log.info('Mega Menu is displayed properly')

        assert storypage.Pattern_Verify()
        log.info('Pattern is displayed properly')

        assert storypage.AllTopics_Verify() == TestData.background_color
        log.info('All Topics menu is greyed out')

        try:
            assert storypage.Breadcrumbs_Verify()
        except:
            log.info('Breadcrumbs is not displayed')

        assert storypage.Menus_Verify()
        log.info('Menus are displayed properly')

        assert storypage.ToggleText_Verify() == TestData.Text
        log.info("Default List view text is displayed")

        assert storypage.ToggleView_Verify()
        log.info('Default contents are displayed in the Grid View')


