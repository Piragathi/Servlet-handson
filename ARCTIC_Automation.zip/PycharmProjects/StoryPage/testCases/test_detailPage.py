from pageObjects.DetailPage import DetailPage
from utilities.BaseClass import BaseClass


class Test_DetailPage(BaseClass):
    def test_Righthandrail_Breadcrumbs(self):
        log = self.get_logger()
        detailpage = DetailPage(self.driver)


        length = detailpage.Length_content()
        detailpage.detailPageMethod(length)
        log.info('Right hand Rail and Breadcrumbs is displayed properly for all the story detail page')


    def test_PrintSave(self):
        log = self.get_logger()
        detailpage = DetailPage(self.driver)

        length = detailpage.Length_content()
        assert detailpage.detailPagebutton(length)
        log.info('Print & Save button is displayed properly')


    def test_socialMediaIcons(self):
        log = self.get_logger()
        detailpage = DetailPage(self.driver)

        length = detailpage.Length_content()
        assert detailpage.SocialMediaIcons_clickable(length)








