import time
from TestData.config import TestData
from pageObjects.StoryPage import StoryPage
from utilities.BaseClass import BaseClass


class Test_BreadCrumbs(BaseClass):
    def test_Firstlevel_breadCrumb(self):
        log = self.get_logger()
        storypage = StoryPage(self.driver)

        storypage.click_discoveryMenu()
        storypage.click_HomeBreadcrumbs()
        time.sleep(2)
        current_URL = storypage.get_currentURL()
        self.driver.back()
        assert TestData.HomePage_URL == current_URL
        log.info('First Level Breadcrumb navigated to Home page')

    def test_Secondlevel_breadCrumb(self):
        log = self.get_logger()
        storypage = StoryPage(self.driver)

        storypage.click_discoveryMenu()
        storypage.click_MediaCenterBreadcrumbs()
        time.sleep(2)
        current_URL = storypage.get_currentURL()
        assert TestData.StoryPage_URL == current_URL
        log.info('Second Level Breadcrumb navigated to Story page')
        assert storypage.AllTopics_Verify() == TestData.background_color
        log.info('All Topics menu is greyed out')


