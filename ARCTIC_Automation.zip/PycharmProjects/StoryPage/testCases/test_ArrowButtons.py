
from pageObjects.StoryPageFooter import StoryPageFooter
from utilities.BaseClass import BaseClass


class Test_ArrowButtons(BaseClass):

    def test_forward_arrow(self):
        log = self.get_logger()
        storypagefooter = StoryPageFooter(self.driver)

        storypagefooter.click_pgNo()
        initailpagno = int(storypagefooter.getText_currentPage())

        storypagefooter.click_forwardButton()

        current_no = int(storypagefooter.getText_currentPage())
        assert initailpagno < current_no
        log.info('Forward button is working,It navigated to the respective forward page')



    def test_backward_arrow(self):
        log = self.get_logger()
        storypagefooter = StoryPageFooter(self.driver)

        initailpagno = int(storypagefooter.getText_currentPage())
        storypagefooter.click_backwarddButton()
        current_no = int(storypagefooter.getText_currentPage())
        assert initailpagno > current_no
        log.info('Backward button is working,It navigated to the respective backward page')