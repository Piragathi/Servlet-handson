
from pageObjects.StoryPage import StoryPage
from utilities.BaseClass import BaseClass


class Test_pagination(BaseClass):
    def test_Pagination(self):
        log = self.get_logger()
        storypage = StoryPage(self.driver)

        assert storypage.get_contentsLength() == 12
        pagination_length = storypage.get_Pagination()
        storypage.Pagination_Method(pagination_length)
        assert storypage.get_contentsLength() == 12
        log.info("Pagination is working properly & it having 12 contents per page")