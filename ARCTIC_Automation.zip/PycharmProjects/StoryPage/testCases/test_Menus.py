from selenium.webdriver.common.by import By

from TestData.config import TestData
from pageObjects.StoryPage import StoryPage
from utilities.BaseClass import BaseClass


class Test_Menus(BaseClass):
  def test_Menus(self):
      log = self.get_logger()
      storypage = StoryPage(self.driver)

      storypage.click_discoveryMenu()
      assert storypage.get_backgroundColor() == TestData.background_color
      log.info('Discovery menu is greyed out')

      assert storypage.Breadcrumbs_Verify()
      log.info('Breadcrumbs is displayed while changing the Menu')


