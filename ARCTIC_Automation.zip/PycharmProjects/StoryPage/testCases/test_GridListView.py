import time

from pageObjects.ToggleView import ToggleView
from utilities.BaseClass import BaseClass


class Test_GridListView(BaseClass):
    def test_ToggleView(self):
        log = self.get_logger()
        View = ToggleView(self.driver)

        View.click_toggleView()
        assert View.Isdisplay_ListView()
        time.sleep(2)
        log.info('List View is rendered when toggle view is rendered')

    def test_GridView(self):
        log = self.get_logger()
        View = ToggleView(self.driver)

        View.click_GridView()
        assert View.Isdisplay_GridView()
        assert View.Isdisplay_ListViewText() == 'List View'
        time.sleep(2)
        log.info('Stories content Pages displayed on Grid View and text change as List view')

    def test_ListView(self):
        log = self.get_logger()
        View = ToggleView(self.driver)

        View.click_ListView()
        assert View.Isdisplay_ListView()
        assert View.Isdisplay_GridViewText() == 'Grid View'
        log.info('Stories content Pages displayed on List View and text change as Grid view')










